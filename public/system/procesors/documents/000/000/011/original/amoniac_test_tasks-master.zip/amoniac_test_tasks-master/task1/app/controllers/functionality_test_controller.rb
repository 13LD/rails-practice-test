class FunctionalityTestController < ApplicationController
  def test
  end
end
