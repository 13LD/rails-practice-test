# DataReverse Sample Gem
This GEM creates the route to `/collect/data` which can be handle the POST 
request and can get the key-value pair information (send with *data* parameter
in JSON format. In result you will get the same information but with reversed
values (in ex. {key1: value, key2: value} => {key1: eulav, key2: eulav}).

This GEM is a sample project and doesn't have any usefulness in general.