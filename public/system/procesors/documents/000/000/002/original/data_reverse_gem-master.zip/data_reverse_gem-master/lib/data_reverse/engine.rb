module DataReverse
  class Engine < ::Rails::Engine
  end
end
