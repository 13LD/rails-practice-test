module Swaggers
  module CashierSetupSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :CashierSetup do
        key :required, [:id, :cashier_cut, :cashier_cut_frequency, :initial_cash, :period]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :cashier_cut do
          key :type, :integer
        end
        property :cashier_cut_frequency do
          key :type, :integer
        end
        property :initial_cash do
          key :type, :integer
        end
        property :period do
          key :type, :string
        end
      end

      swagger_schema :CashierSetupInput do
        allOf do
          schema do
            key :'$ref', :CashierSetup
          end
          schema do
            key :required, [:cashier_cut, :cashier_cut_frequency, :initial_cash, :period]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end