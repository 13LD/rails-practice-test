class AddFieldToTutors < ActiveRecord::Migration[5.0]
  def change
    add_column :tutors, :father_last_name, :string
    add_column :tutors, :mother_last_name, :string
    add_column :tutors, :curp, :string
  end
end
