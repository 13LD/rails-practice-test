class CreateStudentCurrentDetails < ActiveRecord::Migration[5.0]
  def change
    create_table :student_current_details do |t|
      t.string :academic_level_name
      t.string :cycle_name
      t.string :grade_name
      t.string :group_name
      t.integer :academic_level_id
      t.integer :cycle_id
      t.integer :grade_id
      t.integer :group_id
      t.integer :student_id
      t.timestamps
    end
  end
end
