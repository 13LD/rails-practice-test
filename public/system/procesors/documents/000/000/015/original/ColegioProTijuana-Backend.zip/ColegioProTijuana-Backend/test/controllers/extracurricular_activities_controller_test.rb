require 'test_helper'

class ExtracurricularActivitiesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @extracurricular_activity = extracurricular_activities(:one)
  end

  test "should get index" do
    get extracurricular_activities_url, as: :json
    assert_response :success
  end

  test "should create extracurricular_activity" do
    assert_difference('ExtracurricularActivity.count') do
      post extracurricular_activities_url, params: { extracurricular_activity: {  } }, as: :json
    end

    assert_response 201
  end

  test "should show extracurricular_activity" do
    get extracurricular_activity_url(@extracurricular_activity), as: :json
    assert_response :success
  end

  test "should update extracurricular_activity" do
    patch extracurricular_activity_url(@extracurricular_activity), params: { extracurricular_activity: {  } }, as: :json
    assert_response 200
  end

  test "should destroy extracurricular_activity" do
    assert_difference('ExtracurricularActivity.count', -1) do
      delete extracurricular_activity_url(@extracurricular_activity), as: :json
    end

    assert_response 204
  end
end
