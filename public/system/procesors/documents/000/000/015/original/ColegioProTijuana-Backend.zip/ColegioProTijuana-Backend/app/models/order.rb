class Order < ApplicationRecord
  enum status: [ :not_paid, :paid ]
  # Validation
  validates :name, presence: true
  validates :amount, presence: true
  validates :quantity, presence: true

  after_save :register_with_order_conekta
  has_one :payment_method
  belongs_to :user
  accepts_nested_attributes_for :payment_method

  has_many :line_items
  has_many :payments
  def total
    line_items.map(&:total).sum
  end


  def amount_paid
    payments.map(&:amount).sum
  end

  def due
    self.amount + total - amount_paid
  end

  private

  def register_with_order_conekta
    order_conekta = OrderConektaService.new(self).create_order
    self.update(:conekta_id => order_conekta.id) if self.conekta_id.nil? && !conekta_id_changed?
  end
end
