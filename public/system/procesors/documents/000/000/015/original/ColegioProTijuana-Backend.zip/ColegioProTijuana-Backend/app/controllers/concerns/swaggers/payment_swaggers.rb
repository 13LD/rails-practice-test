module Swaggers
  module PaymentSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/payments' do
        operation :get do
          key :description, 'List of Payments'
          key :operationId, 'Payments'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Payment'
          ]
          parameter do
            key :name, :name
            key :in, :query 
            key :description, 'Product Type Name'
            key :required, false
            key :type, :string
            key :'$ref', :PaymentInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Payments List fetched successfully'
            schema do
              key :'$ref', :PaymentInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Payment'
          key :operationId, 'Add Payment'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Payment'
          ]

          parameter do
            key :name, 'payment[student_id]'
            key :in, :query 
            key :description, 'Student Id'
            key :required, false
            key :type, :integer
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[tutor_id]'
            key :in, :query 
            key :description, 'Tutor Id'
            key :required, false
            key :type, :integer
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[status]'
            key :in, :query 
            key :description, 'Payment Status'
            key :required, false
            key :type, :string
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[currency]'
            key :in, :query
            key :description, 'Payment currency (MXN or USD)'
            key :required, false
            key :type, :string
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[exchange_rate]'
            key :in, :query
            key :description, 'Payment exchange rate for USD to MXN'
            key :required, false
            key :type, :float
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[amount]'
            key :in, :query 
            key :description, 'Amount'
            key :required, false
            key :type, :integer
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[payment_method_id]'
            key :in, :query 
            key :description, 'PaymentMethod Id'
            key :required, false
            key :type, :integer
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[order_id]'
            key :in, :query
            key :description, 'Order Id'
            key :required, false
            key :type, :integer
            key :'$ref', :PaymentInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Payment created successfully'
            schema do
              key :'$ref', :PaymentInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/payments/{id}' do
        operation :get do
          key :description, 'Returns a Payment'
          key :operationId, 'find Payment By Id'
          key :tags, [
            'Payment'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Payment to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Payment fetched successfully'
            schema do
              key :'$ref', :PaymentInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a Payment'
          key :operationId, 'Update Payment'
          key :tags, [
            'Payment'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Payment to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end

          parameter do
            key :name, 'payment[student_id]'
            key :in, :query 
            key :description, 'Student Id'
            key :required, false
            key :type, :integer
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[tutor_id]'
            key :in, :query 
            key :description, 'Tutor Id'
            key :required, false
            key :type, :integer
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[status]'
            key :in, :query 
            key :description, 'Payment Status'
            key :required, false
            key :type, :string
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[currency]'
            key :in, :query
            key :description, 'Payment currency (MXN or USD)'
            key :required, false
            key :type, :string
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[exchange_rate]'
            key :in, :query
            key :description, 'Payment exchange rate for USD to MXN'
            key :required, false
            key :type, :float
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[amount]'
            key :in, :query 
            key :description, 'Payment amount'
            key :required, false
            key :type, :integer
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[payment_method_id]'
            key :in, :query 
            key :description, 'PaymentMethod Id'
            key :required, false
            key :type, :integer
            key :'$ref', :PaymentInput
          end
          parameter do
            key :name, 'payment[order_id]'
            key :in, :query
            key :description, 'Order Id'
            key :required, false
            key :type, :integer
            key :'$ref', :PaymentInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Payment Updated successfully'
            schema do
              key :'$ref', :PaymentInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Payment'
          key :operationId, 'delete Payment'
          key :tags, [
            'Payment'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Payment to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Payment Deleted successfully'
            schema do
              key :'$ref', :PaymentInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end
