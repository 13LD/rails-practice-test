class LineItem < ApplicationRecord
  belongs_to :order
  belongs_to :product


  before_save :calculate_total

  private

  def calculate_total
    self.total = unit_price * quantity

  end

end
