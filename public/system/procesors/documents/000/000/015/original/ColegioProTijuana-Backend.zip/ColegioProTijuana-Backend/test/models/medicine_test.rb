require 'test_helper'

class MedicineTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
