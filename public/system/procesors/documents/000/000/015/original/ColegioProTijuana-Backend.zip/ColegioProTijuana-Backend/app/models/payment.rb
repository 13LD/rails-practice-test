class Payment < ApplicationRecord


  # Validation
  validates :status, presence: true
  validates :amount, presence: true

  belongs_to :product_type
  belongs_to :payment_method
  belongs_to :order

  before_save :make_exchange


  def make_exchange
    if self.currency == "USD"
      self.update(
          :amount => (self.amount * self.exchange_rate).to_i,
          :currency => "MXN"
      )
    end
  end
end
