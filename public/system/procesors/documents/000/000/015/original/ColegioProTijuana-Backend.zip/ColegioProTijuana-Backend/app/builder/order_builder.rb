class OrderBuilder
  attr_accessor :params

  def initialize(params)
    @params = params
  end

  def execute
    hashes = @params.dup
    hashes[:payment_method_attributes]= {}
    ActionController::Parameters.permit_all_parameters = true
    hashes[:payment_method_attributes] = ActionController::Parameters.new(payment_type: hashes.delete("payment_type"))
    params = hashes
  end
end
