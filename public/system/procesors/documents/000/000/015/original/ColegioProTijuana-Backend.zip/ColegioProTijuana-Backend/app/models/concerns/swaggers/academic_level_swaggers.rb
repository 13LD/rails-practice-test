module Swaggers
  module AcademicLevelSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :AcademicLevel do
        key :required, [:id, :name, :incorporation_number, :Key]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :name do
          key :type, :string
        end
        property :incorporation_number do
          key :type, :string
        end
        property :Key do
          key :type, :string
        end
      end

      swagger_schema :AcademicLevelInput do
        allOf do
          schema do
            key :'$ref', :AcademicLevel
          end
          schema do
            key :required, [:name, :incorporation_number, :Key]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end
