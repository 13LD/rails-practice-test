class Role < ApplicationRecord
  has_many :users
	enum role_type: [:user, :super_visor, :admin, :tutor, :student_admin, :group_admin]
end
