class PaymentMethod < ApplicationRecord
  enum payment_type: [:cash, :credit_card, :check, :electronic_transfer]

  belongs_to :order
  has_many :payments
end
