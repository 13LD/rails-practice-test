class ProductsController < ApplicationController
  include Swaggers::ProductSwaggers
  before_action :set_product, only: [:show, :update, :destroy]
  before_action :authenticate_user!

  # GET /products
  def index
    if params[:product_type_id]
      @product_type = ProductType.find_by(id: params[:product_type_id])
      if @school_information
        render_success_response(@product_type.products)
      else
        not_found
      end
    else
      @products = Product.all
      render_success_response(@products)
    end
  end

  # GET /products/1
  def show
    if @product
      render_success_response(@product)
    else
      not_found
    end
  end

  # POST /products

  def create
    if ProductType.exists?(params[:product][:product_type_id])
      if params[:product]
        @product = Product.new(product_params)
        if @product.save
          render_success_response(@product.to_json)
        else
          render_error_message("Product can't be saved", 422)
        end
      else
        render_error_message("Missing Parameters", 422)
      end
    else
      render_error_message("Product Type Id doesn't exists", 422)
    end
  end

  # PATCH/PUT /products/1
  def update
    if ProductType.exists?(params[:product][:product_type_id])
      if @product 
        @product.update(product_params)
        render_success_response(@product)
      else
        not_found
      end
    else
      render_error_message("Product Type Id doesn't exists", 422)
    end
  end

  # DELETE /products/1
  def destroy
    if @product
      @product.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_product
      @product = Product.find_by(id: params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def product_params
      params.require(:product).permit(:name, :description, :price, :product_typ, :taxable, :product_type_id, :months_to_pay_ten, :months_to_pay_twelve)
    end
end


