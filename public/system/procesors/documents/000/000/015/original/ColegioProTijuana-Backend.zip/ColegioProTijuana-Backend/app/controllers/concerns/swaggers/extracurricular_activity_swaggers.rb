module Swaggers
  module ExtracurricularActivitySwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/extracurricular_activities' do
       operation :get do
          key :description, 'Returns a Extracurricular activity'
          key :operationId, 'List of Extracurricular activities'
          key :tags, [
            'Extracurricular activity'
          ]
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Extracurricular activity fetched successfully'
            schema do
              key :'$ref', :ExtracurricularActivityInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Extracurricular activity'
          key :operationId, 'Add Extracurricular activity'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Extracurricular activity'
          ]
          parameter do
            key :name, 'extracurricular_activity[academic_level_id]'
            key :in, :query 
            key :description, 'Academic Level Id'
            key :required, true
            key :type, :string
            key :'$ref', :ExtracurricularActivityInput
          end
          parameter do
            key :name, 'extracurricular_activity[name]'
            key :in, :query 
            key :description, 'Extracurricular activity Name'
            key :required, false
            key :type, :string
            key :'$ref', :ExtracurricularActivityInput
          end
          parameter do
            key :name, 'extracurricular_activity[description]'
            key :in, :query 
            key :description, 'Extracurricular activity Description'
            key :required, false
            key :type, :string
            key :'$ref', :ExtracurricularActivityInput
          end
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Extracurricular activity created successfully'
            schema do
              key :'$ref', :ExtracurricularActivityInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/extracurricular_activities/{id}' do
        operation :get do
          key :description, 'Returns a Extracurricular activity'
          key :operationId, 'find Extracurricular activity By Id'
          key :tags, [
            'Extracurricular activity'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Extracurricular activity to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Extracurricular activity fetched successfully'
            schema do
              key :'$ref', :ExtracurricularActivityInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a Extracurricular activity '
          key :operationId, 'Update Extracurricular activity'
          key :tags, [
            'Extracurricular activity'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Extracurricular activity to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'extracurricular_activity[academic_level_id]'
            key :in, :query 
            key :description, 'Academic Level Id'
            key :required, false
            key :type, :string
            key :'$ref', :ExtracurricularActivityInput
          end
          parameter do
            key :name, 'extracurricular_activity[name]'
            key :in, :query 
            key :description, 'Extracurricular activity Name'
            key :required, false
            key :type, :string
            key :'$ref', :ExtracurricularActivityInput
          end
          parameter do
            key :name, 'extracurricular_activity[description]'
            key :in, :query 
            key :description, 'Extracurricular activity Description'
            key :required, false
            key :type, :string
            key :'$ref', :ExtracurricularActivityInput
          end
      
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Extracurricular activity Updated successfully'
            schema do
              key :'$ref', :ExtracurricularActivityInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Extracurricular activity'
          key :operationId, 'delete Extracurricular activity'
          key :tags, [
            'Extracurricular activity'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Extracurricular activity to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Extracurricular activity Deleted successfully'
            schema do
              key :'$ref', :ExtracurricularActivityInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end