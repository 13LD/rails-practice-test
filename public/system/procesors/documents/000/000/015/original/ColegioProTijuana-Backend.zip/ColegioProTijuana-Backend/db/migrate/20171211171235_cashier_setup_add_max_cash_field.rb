class CashierSetupAddMaxCashField < ActiveRecord::Migration[5.0]
  def change
  	add_column :cashier_setups, :max_amount, :integer
  end
end
