class RemoveAddressFromStudents < ActiveRecord::Migration[5.0]
  def change
    remove_column :students, :address, :string
  end
end
