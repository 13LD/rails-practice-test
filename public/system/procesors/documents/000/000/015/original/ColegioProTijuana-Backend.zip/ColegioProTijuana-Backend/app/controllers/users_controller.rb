class UsersController < ApplicationController
  include Swaggers::UserSwaggers
  before_action :set_user, only: [:show, :update, :destroy]
  before_action :authenticate_user!

  # GET /users
  def index
    if params[:school_information_id]
      @school_information = SchoolInformation.find_by(id: params[:school_information_id])
      if @school_information
        render_success_response(@school_information.users)
      else
        not_found
      end
    else
      @users = User.all
      render_success_response(@users)
    end
  end

  # GET /users/1
  def show
    if @user
      render_success_response(@user.to_json(:methods => :role_type))
    else
      not_found
    end
  end

  # POST /users
  def create
    if SchoolInformation.exists?(params[:user][:school_information_id])
      if params[:user]
        @user = User.new(user_params)
        if @user.save
          render_success_response(@user.to_json(:methods => :role_type))
        else
          render_error_message("User can't be saved", 422)
        end
      else
        render_error_message("Missing Parameters", 422)
      end
    else
      render_error_message("School Information Id doesn't exists", 422)
    end
  end

  # PATCH/PUT /users/1
  def update
    if SchoolInformation.exists?(params[:user][:school_information_id])
      if @user 
        @user.update(user_params)
        render_success_response(@user.to_json(:methods => :role_type))
      else
        not_found
      end
    else
      render_error_message("School Information Id doesn't exists", 422)
    end
  end

  # DELETE /users/1
  def destroy
    if @user
      @user.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  def update_role
    @user = User.find_by_id(params[:id])
    if @user
      @user.role_id = params[:user][:role]
      @user.save
      render_success_response(@user.to_json(:methods => :role_type))
    else
      render_error_message("User doesn't exists", 422)
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_user
      @user = User.find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def user_params
      params.require(:user).permit(:email, :password, :password_confirmation, :name, :nickname, :position, :user, :area, :active, :school_information_id, :customer_id, :role_type)
    end

end
