class OrdersController < ApplicationController
  include Swaggers::OrderSwaggers
  before_action :set_order, only: [:show, :update, :destroy]
  before_action :authenticate_user!

  # GET /orders
  def index
    @user = current_user
    @orders = Order.all.where("customer_id = ?", @user.customer_id)
    render_success_response(@orders, include: ['line_items'])
  end

  # GET /orders/1
  def show
    if @order
      render_success_response(@order, include: ['line_items'])
    else
      not_found
    end
  end

  # POST /orders
  def create
    if params[:order]
      attribute = OrderBuilder.new(order_params).execute
      @order = Order.new(attribute)
      if @order.save
        render_success_response(@order)
      else
        render_error_message("Order can't be saved", 422)
      end
    else
      render_error_message("Missing Parameters", 422)
    end
  end

  # PATCH/PUT /orders/1
  # PATCH/PUT /orders/1.json
  def update
    if @order
      attribute = OrderBuilder.new(order_params).execute
      #@order.payment_type = params[:order][:payment_method_attributes][:payment_type]
      @order.update(attribute)
      render_success_response(@order)
    else
      not_found 
    end
  end

  # DELETE /orders/1
  # DELETE /orders/1.json
  def destroy
    if @order
      @order.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_order
      @order = Order.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def order_params
      params.require(:order).permit(:amount, :name, :quantity, :status, :payment_type, :conekta_id, payment_method_attributes: [:id, :payment_type, :_destroy]).merge({customer_id: current_user.customer_id})
    end
end
