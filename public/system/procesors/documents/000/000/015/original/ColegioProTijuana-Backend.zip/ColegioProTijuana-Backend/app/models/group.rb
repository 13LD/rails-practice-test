class Group < ApplicationRecord

  # Validation
  validates :name, presence: true
  validates :maximum_capacity, presence: true

  belongs_to :grade
  has_many :group_cycles
  has_many :cycles, through: :group_cycles
  has_many :student_current_details
end
