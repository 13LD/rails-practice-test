class OrderConektaService
  def initialize(order)
    @order = order
  end

  def create_order
    order_conekta = Conekta::Order.create({
      :currency => "MXN",
      :customer_info => {
        :customer_id => @order.customer_id
      },
      :line_items => [{
        :name => @order.name,
        :unit_price => @order.amount,
        :quantity => @order.quantity
      }],
      :charges => [{
        :payment_method => {
          :type => "oxxo_cash"
        }
      }]
    })

  end


end
