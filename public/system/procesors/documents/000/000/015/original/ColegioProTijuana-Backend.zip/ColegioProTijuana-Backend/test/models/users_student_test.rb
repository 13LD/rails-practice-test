require 'test_helper'

class UsersStudentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
