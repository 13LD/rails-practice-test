class AddSchoolInformationIdToAcademicLevels < ActiveRecord::Migration[5.0]
  def change
    add_column :academic_levels, :school_information_id, :integer
    add_index :academic_levels, :school_information_id
  end
end
