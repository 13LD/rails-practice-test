class DocumentsController < ApplicationController
  before_action :authenticate_user!

  def create
    if !current_user.role.tutor?
      @document = Document.new(document_params)
      if @document.save
        render json: { success: ['File uploaded and students created.'] }, status: :created
      else
        render json: { errors: @document.errors.full_messages },
               status: :unprocessable_entity
      end
    else
      render json: { errors: "You are not authorized." },
             status: :unprocessable_entity
    end
  end

  private
  
    def document_params
      params.require(:document).permit(:document).merge({user_id: current_user.id})
    end
end
