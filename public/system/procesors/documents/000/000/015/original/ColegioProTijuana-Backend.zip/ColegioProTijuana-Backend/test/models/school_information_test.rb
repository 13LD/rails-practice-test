require 'test_helper'

class SchoolInformationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
