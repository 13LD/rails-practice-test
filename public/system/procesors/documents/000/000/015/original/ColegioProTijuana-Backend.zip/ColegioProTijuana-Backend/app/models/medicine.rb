class Medicine < ApplicationRecord

  # Validation
  validates :name, presence: true

  belongs_to :student
end
