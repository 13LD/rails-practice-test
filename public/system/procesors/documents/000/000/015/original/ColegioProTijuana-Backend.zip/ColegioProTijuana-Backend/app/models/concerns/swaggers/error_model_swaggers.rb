module Swaggers
  module ErrorModelSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :ErrorModel do
        key :required, [:code, :message]
        property :code do
          key :type, :integer
          key :format, :int32
        end
        property :message do
          key :type, :string
        end
      end
    end
  end
end