require 'test_helper'

class TutorReportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
