module Swaggers
  module MedicineSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/medicines' do
        operation :get do
          key :description, 'List of Medicines'
          key :operationId, 'Medicines'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Medicine'
          ]
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Medicines List fetched successfully'
            schema do
              key :'$ref', :MedicineInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Medicine'
          key :operationId, 'Add Medicine'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Medicine'
          ]
          
          parameter do
            key :name, 'medicine[name]'
            key :in, :query 
            key :description, 'Medicine Name'
            key :required, false
            key :type, :string
            key :'$ref', :MedicineInput
          end
          parameter do
            key :name, 'medicine[student_id]'
            key :in, :query 
            key :description, 'Student Id'
            key :required, true
            key :type, :string
            key :'$ref', :MedicineInput
          end
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Medicine created successfully'
            schema do
              key :'$ref', :MedicineInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/medicines/{id}' do
        operation :get do
          key :description, 'Returns a Medicine'
          key :operationId, 'find Medicine By Id'
          key :tags, [
            'Medicine'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Medicine to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Medicine fetched successfully'
            schema do
              key :'$ref', :MedicineInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a Medicine '
          key :operationId, 'Update Medicine'
          key :tags, [
            'Medicine'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Medicine to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'medicine[student_id]'
            key :in, :query 
            key :description, 'Student Id'
            key :required, true
            key :type, :string
            key :'$ref', :MedicineInput
          end
          parameter do
            key :name, 'medicine[name]'
            key :in, :query 
            key :description, 'Medicine Name'
            key :required, false
            key :type, :string
            key :'$ref', :MedicineInput
          end
      
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Medicine Updated successfully'
            schema do
              key :'$ref', :MedicineInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Medicine'
          key :operationId, 'delete Medicine'
          key :tags, [
            'Medicine'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Medicine to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Medicine Deleted successfully'
            schema do
              key :'$ref', :MedicineInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end
