module Swaggers
  module ExtracurricularActivitySwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :ExtracurricularActivity do
        key :required, [:id, :academic_level_id, :name, :description]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :academic_level_id do
          key :type, :integer
        end
        property :name do
          key :type, :string
        end
        property :description do
          key :type, :text
        end
      end

      swagger_schema :ExtracurricularActivityInput do
        allOf do
          schema do
            key :'$ref', :ExtracurricularActivity
          end
          schema do
            key :required, [:academic_level_id, :name, :description]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end