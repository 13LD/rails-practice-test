Rails.application.routes.draw do
  resources :tutor_reports
  resources :line_items
  resources :authorized_people do
    post "authorized_people_list", on: :collection
  end 
  resources :medicines do 
    post 'medicines_list', on: :collection
  end
  resources :notifications
  resources :extracurricular_activities
  root to: "home#index"
  get '/api' => redirect('/swagger/dist/index.html?url=/apidocs.json')
  get '/conekta' => redirect('/conekta.js-0.6.0/examples/credit_card.html')
  mount_devise_token_auth_for 'User', at: 'auth',skip: [:invitations],controllers: {
    confirmations:      'devise_token_auth/confirmations',
    passwords:          'devise_token_auth/passwords',
    omniauth_callbacks: 'devise_token_auth/omniauth_callbacks',
    registrations:      'registrations',
    sessions:           'sessions',
    token_validations:  'devise_token_auth/token_validations'
  }

  devise_for :users, path: "auth", only: [:invitations],
      controllers: { invitations: 'invitations', registrations: 'registrations' }

  resources :apidocs, only: [:index]
  
  resources :roles
  
  resources :users

  resources :documents, only: [:create]

  resources :students do
    collection do
      get :download_pdf
      get :delete_pdf
    end
  end
  resources :cashier_setups
  resources :grades
  resources :groups
  resources :cycles
  resources :academic_levels
  resources :payments
  resources :payment_methods
  resources :product_types
  resources :products
  resources :tutors
  resources :orders
  resources :school_informations
  resources :student_group_cycles, controller: 'allotments'
  post "/activate/:id", to: "students#activate"
  post "/deactivate/:id", to: "students#deactivate"
  get "/receive", to: "webhooks#receive"
  post "/create_tutor_with_student", to: "tutors#create_tutor_with_student"
  put "/update_tutor_with_student/:id", to: "tutors#update_tutor_with_student"
  delete "delete_student/:id", to: "tutors#delete_student"
  get "/show_student_enrollment/:id", to: "tutors#show_student_of_tutor"
  get "/show_students_of_tutor/:id", to: "tutors#show_students_of_tutor"
  put "/update_role/:id", to: "users#update_role"
  put "update_cycle_and_student_status/:id", to:"cycles#update_cycle_and_student_status"
  get "/show_tutors_payments", to: "tutors#show_tutors_payments"
  get "/last_notification", to: "tutors#last_notification"
end
