class PaymentMethodsController < ApplicationController
  include Swaggers::PaymentMethodSwaggers
  before_action :set_payment_method, only: [:show, :update, :destroy]
  before_action :authenticate_user!

  # GET /payment_methods
  def index
    @payment_methods = PaymentMethod.all
    render_success_response(@payment_methods)
  end

  # GET /payment_methods/1
  def show
    if @payment_method
      render_success_response(@payment_method)
    else
      not_found
    end
  end

  # POST /payment_methods
  def create
    if params[:payment_method]
      @payment_method = PaymentMethod.new(payment_method_params)
      if @payment_method.save
        render_success_response(@payment_method)
      else
        render_error_message("Payment Method can't be saved", 422)
      end
    else
      render_error_message("Missing Parameters", 422)
    end
  end

  # PATCH/PUT /payment_methods/1
  def update
    if @payment_method 
      @payment_method.update(payment_method_params)
      render_success_response(@payment_method)
    else
      not_found
    end
  end

  # DELETE /payment_methods/1
  def destroy
    if @payment_method
      @payment_method.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_payment_method
      @payment_method = PaymentMethod.find_by(id: params[:id])
      # unless @payment_method.present?
      #   not_found and return
      # end
    end

    # Only allow a trusted parameter "white list" through.
    def payment_method_params
      params.require(:payment_method).permit(:name, :description, :payment_type)
    end
end
