class AddMonthsToProducts < ActiveRecord::Migration[5.0]
  def change
    add_column :products, :months_to_pay_ten, :boolean
    add_column :products, :months_to_pay_twelve, :boolean
  end
end
