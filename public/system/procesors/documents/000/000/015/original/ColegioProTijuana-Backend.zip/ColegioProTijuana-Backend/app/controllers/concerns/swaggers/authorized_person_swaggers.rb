module Swaggers
  module AuthorizedPersonSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/authorized_people' do
        operation :get do
          key :description, 'List of Authorized people'
          key :operationId, 'Authorized people'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Authorized person'
          ]
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Authorized people List fetched successfully'
            schema do
              key :'$ref', :AuthorizedPersonInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Authorized person'
          key :operationId, 'Add Authorized person'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Authorized person'
          ]
          
          parameter do
            key :name, 'authorized_person[name]'
            key :in, :query 
            key :description, 'Authorized person Name'
            key :required, false
            key :type, :string
            key :'$ref', :AuthorizedPersonInput
          end
          parameter do
            key :name, 'authorized_person[student_id]'
            key :in, :query 
            key :description, 'Student Id'
            key :required, true
            key :type, :string
            key :'$ref', :AuthorizedPersonInput
          end
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Authorized person created successfully'
            schema do
              key :'$ref', :AuthorizedPersonInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/authorized_people/{id}' do
        operation :get do
          key :description, 'Returns a Authorized person'
          key :operationId, 'find Authorized person By Id'
          key :tags, [
            'Authorized person'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Authorized person to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Authorized person fetched successfully'
            schema do
              key :'$ref', :AuthorizedPersonInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a Authorized person '
          key :operationId, 'Update Authorized person'
          key :tags, [
            'Authorized person'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Authorized person to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'authorized_person[student_id]'
            key :in, :query 
            key :description, 'Student Id'
            key :required, true
            key :type, :string
            key :'$ref', :AuthorizedPersonInput
          end
          parameter do
            key :name, 'authorized_person[name]'
            key :in, :query 
            key :description, 'Authorized person Name'
            key :required, false
            key :type, :string
            key :'$ref', :AuthorizedPersonInput
          end
      
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Authorized person Updated successfully'
            schema do
              key :'$ref', :AuthorizedPersonInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Authorized person'
          key :operationId, 'delete Authorized person'
          key :tags, [
            'Authorized person'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Authorized Person to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Authorized person Deleted successfully'
            schema do
              key :'$ref', :AuthorizedPersonInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end
