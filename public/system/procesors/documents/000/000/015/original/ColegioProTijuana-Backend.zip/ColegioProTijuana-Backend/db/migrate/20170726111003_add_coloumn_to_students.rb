class AddColoumnToStudents < ActiveRecord::Migration[5.0]
  def change
    add_column :students, :father_last_name, :string
    add_column :students, :mother_last_name, :string
  end
end
