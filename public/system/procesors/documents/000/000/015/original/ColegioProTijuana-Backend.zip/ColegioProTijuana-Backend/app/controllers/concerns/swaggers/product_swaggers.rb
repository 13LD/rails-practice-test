module Swaggers
  module ProductSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/products' do
        operation :get do
          key :description, 'List of Products'
          key :operationId, 'Products'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Product'
          ]
           parameter do
            key :name, :product_type_id
            key :in, :query
            key :description, 'ID of Product Type to fetch its Products'
            key :required, false
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Products List fetched successfully'
            schema do
              key :'$ref', :ProductInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Product'
          key :operationId, 'Add Product'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Product'
          ]
          parameter do
            key :name, 'product[product_type_id]'
            key :in, :query 
            key :description, 'Product Type Id '
            key :required, true
            key :type, :string
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[name]'
            key :in, :query 
            key :description, 'Product Name'
            key :required, false
            key :type, :string
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[description]'
            key :in, :query 
            key :description, 'Product Description'
            key :required, false
            key :type, :text
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[price]'
            key :in, :query 
            key :description, 'Product price'
            key :required, false
            key :type, :integer
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[taxable]'
            key :in, :query 
            key :description, 'Product Taxable'
            key :required, false
            key :type, :boolean
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[product_typ]'
            key :in, :query 
            key :description, 'Product Type'
            key :required, false
            key :type, :string
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[months_to_pay_ten]'
            key :in, :query 
            key :description, 'Months to Pay Ten'
            key :required, false
            key :type, :boolean
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[months_to_pay_twelve]'
            key :in, :query 
            key :description, 'Months to Pay Twelve'
            key :required, false
            key :type, :boolean
            key :'$ref', :ProductInput
          end
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Product created successfully'
            schema do
              key :'$ref', :ProductInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/products/{id}' do
        operation :get do
          key :description, 'Returns a Product'
          key :operationId, 'find Product By Id'
          key :tags, [
            'Product'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Product to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Product fetched successfully'
            schema do
              key :'$ref', :ProductInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a Product '
          key :operationId, 'Update Product'
          key :tags, [
            'Product'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Product to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'product[product_type_id]'
            key :in, :query 
            key :description, 'Product Type Id '
            key :required, false
            key :type, :string
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[name]'
            key :in, :query 
            key :description, 'Product Name'
            key :required, false
            key :type, :string
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[description]'
            key :in, :query 
            key :description, 'Product Description'
            key :required, false
            key :type, :text
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[price]'
            key :in, :query 
            key :description, 'Product price'
            key :required, false
            key :type, :integer
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[taxable]'
            key :in, :query 
            key :description, 'Product Taxable'
            key :required, false
            key :type, :boolean
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[product_typ]'
            key :in, :query 
            key :description, 'Product Type'
            key :required, false
            key :type, :string
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[months_to_pay_ten]'
            key :in, :query 
            key :description, 'Months to Pay Ten'
            key :required, false
            key :type, :boolean
            key :'$ref', :ProductInput
          end
          parameter do
            key :name, 'product[months_to_pay_twelve]'
            key :in, :query 
            key :description, 'Months to Pay Twelve'
            key :required, false
            key :type, :boolean
            key :'$ref', :ProductInput
          end
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Product Updated successfully'
            schema do
              key :'$ref', :ProductInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Product'
          key :operationId, 'delete Product'
          key :tags, [
            'Product'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Product to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Product Deleted successfully'
            schema do
              key :'$ref', :ProductInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end
