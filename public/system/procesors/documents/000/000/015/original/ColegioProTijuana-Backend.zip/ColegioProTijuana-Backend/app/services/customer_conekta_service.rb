class CustomerConektaService
  def initialize(user)
    @user = user
  end

  #
  def create_customer
    customer = Conekta::Customer.create({
      :name => @user.name,
      :email => @user.email,
      :phone => "1234567890",
      :plan_id => "gold-plan",
      :corporate => true,
      :payment_sources => [{
        :token_id => "tok_test_visa_4242",
        :type => "card"
      }],
      :shipping_contacts => [{
        :phone => "+5215555555555",
        :receiver => "Marvin Fuller",
        :between_streets => "Ackerman Crescent",
        :address => {
          :street1 => "250 Alexis St",
          :street2 => "fake street",
          :city => "Red Deer",
          :state => "Alberta",
          :country => "CA",
          :postal_code => "T4N 0B8",
          :residential => true
        }
      }]
    })
  end
end
