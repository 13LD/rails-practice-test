class AcademicLevelsController < ApplicationController
  include Swaggers::AcademicLevelSwaggers
  before_action :set_academic_level, only: [:show, :update, :destroy]
  before_action :authenticate_user!

  # GET /academic_levels
  def index
    if params[:school_information_id]
      @school_information = SchoolInformation.find_by(id: params[:school_information_id])
      if @school_information
        render_success_response(@school_information.academic_levels)
      else
        not_found
      end
    else
      @academic_levels = AcademicLevel.all
      render_success_response(@academic_levels)
    end
  end

  # GET /academic_levels/1
  def show
    if @academic_level
      render_success_response(@academic_level)
    else
      not_found
    end
  end

  # POST /academic_levels
  def create
    if SchoolInformation.exists?(params[:academic_level][:school_information_id])
      if params[:academic_level]
        @academic_level = AcademicLevel.new(academic_level_params)
        if @academic_level.save
          render_success_response(@academic_level)
        else
          render_error_message("Academic Level can't be saved", 422)
        end
      else
        render_error_message("Missing Parameters", 422)
      end
    else
      render_error_message("School Information Id doesn't exists", 422)
    end
  end

  # PATCH/PUT /academic_levels/1
  def update
    if SchoolInformation.exists?(params[:academic_level][:school_information_id])
      if @academic_level 
        @academic_level.update(academic_level_params)
        render_success_response(@academic_level)
      else
        not_found
      end
    else
      render_error_message("School Information Id doesn't exists", 422)
    end
  end

  # DELETE /academic_levels/1
  def destroy
    if @academic_level
      @academic_level.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_academic_level
      @academic_level = AcademicLevel.find_by(id: params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def academic_level_params
      params.require(:academic_level).permit(:name, :school_information_id, :incorporation_number, :Key)
    end

end
