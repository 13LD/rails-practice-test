module Swaggers
  module CashierSetupSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/cashier_setups' do
        operation :get do
          key :description, 'List of Cashier Setups'
          key :operationId, 'Cashier Setups'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Cashier setup'
          ]
          parameter do
            key :name, :id
            key :in, :query 
            key :description, 'Cashier Id'
            key :required, false
            key :type, :integer
            key :'$ref', :CashierSetupInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Cashier Setups fetched successfully'
            schema do
              key :'$ref', :CashierSetupInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Cashier Setup'
          key :operationId, 'Add Cashier Setup'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Cashier setup'
          ]
          parameter do
            key :name, 'cashier_setup[cashier_cut]'
            key :in, :query 
            key :description, 'Cashier Cut'
            key :required, false
            key :type, :integer
            key :'$ref', :CashierSetupInput
          end
          parameter do
            key :name, 'cashier_setup[cashier_cut_frequency]'
            key :in, :query 
            key :description, 'Cashier cut Frequency'
            key :required, false
            key :type, :integer
            key :'$ref', :CashierSetupInput
          end
          parameter do
            key :name, 'cashier_setup[initial_cash]'
            key :in, :query 
            key :description, 'Initial Cash'
            key :required, false
            key :type, :integer
            key :'$ref', :CashierSetupInput
          end
          parameter do
            key :name, 'cashier_setup[period]'
            key :in, :query 
            key :description, 'Period'
            key :required, false
            key :type, :string
            key :'$ref', :CashierSetupInput
          end
          parameter do
            key :name, 'cashier_setup[max_amount]'
            key :in, :query 
            key :description, 'Max Amount'
            key :required, false
            key :type, :integer
            key :'$ref', :CashierSetupInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Cashier Setup created successfully'
            schema do
              key :'$ref', :CashierSetupInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/cashier_setups/{id}' do
        operation :get do
          key :description, 'Returns a Cashier Setup'
          key :operationId, 'find Cashier Setup By Id'
          key :tags, [
            'Cashier setup'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Cashier Setup to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Cashier Setup fetched successfully'
            schema do
              key :'$ref', :CashierSetupInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a Cashier Setup'
          key :operationId, 'Update Cashier Setup'
          key :tags, [
            'Cashier setup'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Cashier Setup to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'cashier_setup[cashier_cut]'
            key :in, :query 
            key :description, 'Cashier Cut'
            key :required, false
            key :type, :integer
            key :'$ref', :CashierSetupInput
          end
          parameter do
            key :name, 'cashier_setup[cashier_cut_frequency]'
            key :in, :query 
            key :description, 'Cashier cut Frequency'
            key :required, false
            key :type, :integer
            key :'$ref', :CashierSetupInput
          end
          parameter do
            key :name, 'cashier_setup[initial_cash]'
            key :in, :query 
            key :description, 'Initial Cash'
            key :required, false
            key :type, :integer
            key :'$ref', :CashierSetupInput
          end
          parameter do
            key :name, 'cashier_setup[period]'
            key :in, :query 
            key :description, 'Period'
            key :required, false
            key :type, :string
            key :'$ref', :CashierSetupInput
          end
          parameter do
            key :name, 'cashier_setup[max_amount]'
            key :in, :query 
            key :description, 'Max Amount'
            key :required, false
            key :type, :integer
            key :'$ref', :CashierSetupInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Cashier Setup updated successfully'
            schema do
              key :'$ref', :CashierSetupInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Cashier Setup'
          key :operationId, 'delete Cashier Setup'
          key :tags, [
            'Cashier setup'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Cashier Setup to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Cashier Setup Deleted Successfully'
            schema do
              key :'$ref', :CashierSetupInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end