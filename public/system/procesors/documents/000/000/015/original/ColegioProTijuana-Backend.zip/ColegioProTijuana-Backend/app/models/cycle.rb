class Cycle < ApplicationRecord 
  # after_create :set_variable

  # Validation
  validates :number, presence: true
  validates :start_date, presence: true
  validates :end_date, presence: true

  has_many :group_cycles
  has_many :groups, through: :group_cycles
  has_many :students, through: :group_cycles
  has_many :student_current_details

  # def set_variable
  #   if Cycle.last.start_date.year != Time.now.year
  #     $global = 1
  #   end
  # end

  def name
    start_date.year.to_s + '-' + end_date.year.to_s
  end
end
