class CreateStudentGroupCycles < ActiveRecord::Migration[5.0]
  def change
    create_table :student_group_cycles do |t|
      t.integer :student_id
      t.integer :group_cycle_id

      t.timestamps
    end
    add_index :student_group_cycles, :student_id
    add_index :student_group_cycles, :group_cycle_id
  end
end
