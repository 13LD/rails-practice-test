class AddFieldsToStudents < ActiveRecord::Migration[5.0]
  def change
    add_column :students, :middle_name, :string
    add_column :students, :birthday, :date
    add_column :students, :sex, :string
    add_column :students, :address, :string
    add_column :students, :tutor, :string
    add_column :students, :control_number, :integer
    add_column :students, :age, :integer
    add_column :students, :phone, :integer
    add_column :students, :cell_phone, :integer
    add_column :students, :live_with, :string
    add_column :students, :type_of_scholarship, :string
    add_column :students, :curp, :string
    add_column :students, :rfc, :string
    add_column :students, :official_docs, :string
  end
end
