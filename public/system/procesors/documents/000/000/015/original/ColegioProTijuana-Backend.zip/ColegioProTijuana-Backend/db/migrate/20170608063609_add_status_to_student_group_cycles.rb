class AddStatusToStudentGroupCycles < ActiveRecord::Migration[5.0]
  def change
    add_column :student_group_cycles, :status, :integer
  end
end
