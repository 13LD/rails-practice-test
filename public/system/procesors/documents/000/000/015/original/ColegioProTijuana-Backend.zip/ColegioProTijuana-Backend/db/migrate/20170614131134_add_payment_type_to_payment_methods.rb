class AddPaymentTypeToPaymentMethods < ActiveRecord::Migration[5.0]
  def change
    add_column :payment_methods, :payment_type, :integer
  end
end
