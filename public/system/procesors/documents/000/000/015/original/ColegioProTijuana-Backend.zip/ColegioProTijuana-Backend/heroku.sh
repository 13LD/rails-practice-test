git push heroku master && heroku run rake db:migrate && heroku restart
