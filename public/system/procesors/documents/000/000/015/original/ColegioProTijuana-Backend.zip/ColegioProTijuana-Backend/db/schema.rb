# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20180311111959) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "academic_levels", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at",            null: false
    t.datetime "updated_at",            null: false
    t.integer  "school_information_id"
    t.string   "incorporation_number"
    t.string   "Key"
    t.index ["school_information_id"], name: "index_academic_levels_on_school_information_id", using: :btree
  end

  create_table "authorized_people", force: :cascade do |t|
    t.string   "name"
    t.integer  "student_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["student_id"], name: "index_authorized_people_on_student_id", using: :btree
  end

  create_table "cashier_setups", force: :cascade do |t|
    t.integer  "cashier_cut"
    t.integer  "cashier_cut_frequency"
    t.integer  "initial_cash"
    t.datetime "created_at",            null: false
    t.datetime "updated_at",            null: false
    t.integer  "period"
    t.integer  "max_amount"
  end

  create_table "cycles", force: :cascade do |t|
    t.integer  "number"
    t.date     "start_date"
    t.date     "end_date"
    t.string   "status"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "documents", force: :cascade do |t|
    t.integer  "user_id"
    t.string   "document"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_documents_on_user_id", using: :btree
  end

  create_table "error_models", force: :cascade do |t|
    t.integer  "code"
    t.string   "message"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "extracurricular_activities", force: :cascade do |t|
    t.string   "name"
    t.string   "description"
    t.integer  "academic_level_id"
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
    t.index ["academic_level_id"], name: "index_extracurricular_activities_on_academic_level_id", using: :btree
  end

  create_table "grades", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
    t.integer  "group_id"
    t.integer  "academic_level_id"
    t.index ["academic_level_id"], name: "index_grades_on_academic_level_id", using: :btree
    t.index ["group_id"], name: "index_grades_on_group_id", using: :btree
  end

  create_table "group_cycles", force: :cascade do |t|
    t.integer  "group_id"
    t.integer  "cycle_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["cycle_id"], name: "index_group_cycles_on_cycle_id", using: :btree
    t.index ["group_id"], name: "index_group_cycles_on_group_id", using: :btree
  end

  create_table "groups", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at",       null: false
    t.datetime "updated_at",       null: false
    t.integer  "grade_id"
    t.integer  "maximum_capacity"
    t.index ["grade_id"], name: "index_groups_on_grade_id", using: :btree
  end

  create_table "line_items", force: :cascade do |t|
    t.string   "product_name"
    t.integer  "quantity"
    t.float    "unit_price"
    t.float    "total"
    t.integer  "order_id"
    t.integer  "product_id"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
    t.float    "discount"
    t.index ["order_id"], name: "index_line_items_on_order_id", using: :btree
    t.index ["product_id"], name: "index_line_items_on_product_id", using: :btree
  end

  create_table "medicines", force: :cascade do |t|
    t.string   "name"
    t.integer  "student_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["student_id"], name: "index_medicines_on_student_id", using: :btree
  end

  create_table "notifications", force: :cascade do |t|
    t.string   "message"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "orders", force: :cascade do |t|
    t.integer  "amount"
    t.string   "customer_id"
    t.string   "name"
    t.integer  "quantity"
    t.datetime "created_at",              null: false
    t.datetime "updated_at",              null: false
    t.string   "conekta_id"
    t.integer  "status",      default: 0
  end

  create_table "payment_methods", force: :cascade do |t|
    t.string   "name"
    t.text     "description"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
    t.integer  "order_id"
    t.integer  "payment_type"
    t.index ["order_id"], name: "index_payment_methods_on_order_id", using: :btree
  end

  create_table "payments", force: :cascade do |t|
    t.string   "status"
    t.integer  "amount"
    t.integer  "student_id"
    t.integer  "tutor_id"
    t.integer  "created_by"
    t.datetime "created_at",                                                null: false
    t.datetime "updated_at",                                                null: false
    t.integer  "product_type_id"
    t.integer  "payment_method_id"
    t.integer  "order_id"
    t.string   "currency",                                  default: "MXN", null: false
    t.decimal  "exchange_rate",     precision: 6, scale: 3, default: "0.0"
    t.index ["order_id"], name: "index_payments_on_order_id", using: :btree
    t.index ["product_type_id"], name: "index_payments_on_product_type_id", using: :btree
  end

  create_table "product_types", force: :cascade do |t|
    t.string   "name"
    t.text     "description"
    t.datetime "created_at",            null: false
    t.datetime "updated_at",            null: false
    t.integer  "school_information_id"
    t.index ["school_information_id"], name: "index_product_types_on_school_information_id", using: :btree
  end

  create_table "products", force: :cascade do |t|
    t.string   "name"
    t.text     "description"
    t.datetime "created_at",           null: false
    t.datetime "updated_at",           null: false
    t.integer  "user_id"
    t.integer  "price"
    t.boolean  "taxable"
    t.integer  "product_type_id"
    t.string   "product_typ"
    t.boolean  "months_to_pay_ten"
    t.boolean  "months_to_pay_twelve"
    t.index ["product_type_id"], name: "index_products_on_product_type_id", using: :btree
    t.index ["user_id"], name: "index_products_on_user_id", using: :btree
  end

  create_table "roles", force: :cascade do |t|
    t.datetime "created_at",              null: false
    t.datetime "updated_at",              null: false
    t.integer  "role_type",   default: 0
    t.string   "name"
    t.text     "description"
  end

  create_table "school_informations", force: :cascade do |t|
    t.string   "name"
    t.string   "sep"
    t.string   "fiscal_address"
    t.string   "rfc"
    t.string   "business_name"
    t.integer  "phone"
    t.integer  "emergency_phone"
    t.string   "legal_guardian"
    t.datetime "created_at",      null: false
    t.datetime "updated_at",      null: false
  end

  create_table "student_current_details", force: :cascade do |t|
    t.string   "academic_level_name"
    t.string   "cycle_name"
    t.string   "grade_name"
    t.string   "group_name"
    t.integer  "academic_level_id"
    t.integer  "cycle_id"
    t.integer  "grade_id"
    t.integer  "group_id"
    t.integer  "student_id"
    t.datetime "created_at",          null: false
    t.datetime "updated_at",          null: false
    t.integer  "payment_type"
  end

  create_table "student_group_cycles", force: :cascade do |t|
    t.integer  "student_id"
    t.integer  "group_cycle_id"
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
    t.integer  "status"
    t.integer  "payment_type"
    t.index ["group_cycle_id"], name: "index_student_group_cycles_on_group_cycle_id", using: :btree
    t.index ["student_id"], name: "index_student_group_cycles_on_student_id", using: :btree
  end

  create_table "students", force: :cascade do |t|
    t.string   "first_name"
    t.string   "last_name"
    t.integer  "created_by"
    t.datetime "created_at",                                    null: false
    t.datetime "updated_at",                                    null: false
    t.string   "email"
    t.string   "middle_name"
    t.date     "birthday"
    t.string   "sex"
    t.integer  "control_number"
    t.integer  "age"
    t.integer  "phone"
    t.integer  "cell_phone"
    t.string   "live_with"
    t.string   "type_of_scholarship"
    t.string   "curp"
    t.string   "rfc"
    t.string   "official_docs"
    t.integer  "tutor_id"
    t.boolean  "is_active",                     default: false
    t.string   "student_picture"
    t.string   "birth_certificate"
    t.string   "curp_document"
    t.string   "proof_of_address"
    t.string   "father_last_name"
    t.string   "mother_last_name"
    t.string   "address_street"
    t.string   "address_colony"
    t.string   "address_number"
    t.string   "address_postal_code"
    t.string   "address_city"
    t.string   "address_state"
    t.string   "numbers"
    t.string   "enrollment_number"
    t.string   "extra_contact_number"
    t.string   "extra_contact_email"
    t.string   "father_name"
    t.string   "mother_name"
    t.boolean  "has_disease",                   default: false
    t.string   "disease_name"
    t.boolean  "has_allergic",                  default: false
    t.string   "allergic_name"
    t.boolean  "has_treatment",                 default: false
    t.string   "treatment_name"
    t.string   "doctor_name"
    t.string   "doctor_number"
    t.boolean  "has_to_take_medicine",          default: false
    t.string   "certificate_of_qualifications"
    t.string   "unsubscribe_folio"
    t.string   "regulation"
    t.boolean  "extended_time",                 default: false
    t.integer  "extracurricular_activity_id"
    t.index ["extracurricular_activity_id"], name: "index_students_on_extracurricular_activity_id", using: :btree
    t.index ["tutor_id"], name: "index_students_on_tutor_id", using: :btree
  end

  create_table "tutor_reports", force: :cascade do |t|
    t.string   "tutor_name"
    t.string   "tutor_curp"
    t.string   "tutor_email"
    t.integer  "tutor_id"
    t.integer  "user_id"
    t.string   "payment_type"
    t.integer  "order_id"
    t.float    "amount_paid"
    t.float    "funded"
    t.float    "pending_amount"
    t.float    "total_amount"
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
    t.index ["order_id"], name: "index_tutor_reports_on_order_id", using: :btree
    t.index ["tutor_id"], name: "index_tutor_reports_on_tutor_id", using: :btree
    t.index ["user_id"], name: "index_tutor_reports_on_user_id", using: :btree
  end

  create_table "tutors", force: :cascade do |t|
    t.string   "name"
    t.string   "last_name"
    t.string   "title"
    t.integer  "phone"
    t.integer  "cell_phone"
    t.integer  "work_phone"
    t.integer  "emergency_phone"
    t.string   "email"
    t.datetime "created_at",       null: false
    t.datetime "updated_at",       null: false
    t.integer  "user_id"
    t.string   "rfc"
    t.string   "father_last_name"
    t.string   "mother_last_name"
    t.string   "curp"
    t.index ["user_id"], name: "index_tutors_on_user_id", using: :btree
  end

  create_table "users", force: :cascade do |t|
    t.string   "provider",               default: "email", null: false
    t.string   "uid",                    default: "",      null: false
    t.string   "encrypted_password",     default: "",      null: false
    t.string   "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",          default: 0,       null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.string   "current_sign_in_ip"
    t.string   "last_sign_in_ip"
    t.string   "confirmation_token"
    t.datetime "confirmed_at"
    t.datetime "confirmation_sent_at"
    t.string   "unconfirmed_email"
    t.string   "name"
    t.string   "nickname"
    t.string   "image"
    t.string   "email"
    t.json     "tokens"
    t.datetime "created_at",                               null: false
    t.datetime "updated_at",                               null: false
    t.string   "invitation_token"
    t.datetime "invitation_created_at"
    t.datetime "invitation_sent_at"
    t.datetime "invitation_accepted_at"
    t.integer  "invitation_limit"
    t.string   "invited_by_type"
    t.integer  "invited_by_id"
    t.integer  "invitations_count",      default: 0
    t.string   "mobile"
    t.string   "position"
    t.string   "user"
    t.string   "area"
    t.string   "active"
    t.integer  "school_information_id"
    t.string   "customer_id"
    t.integer  "role_id"
    t.index ["confirmation_token"], name: "index_users_on_confirmation_token", unique: true, using: :btree
    t.index ["email"], name: "index_users_on_email", unique: true, using: :btree
    t.index ["invitation_token"], name: "index_users_on_invitation_token", unique: true, using: :btree
    t.index ["invitations_count"], name: "index_users_on_invitations_count", using: :btree
    t.index ["invited_by_id"], name: "index_users_on_invited_by_id", using: :btree
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true, using: :btree
    t.index ["role_id"], name: "index_users_on_role_id", using: :btree
    t.index ["school_information_id"], name: "index_users_on_school_information_id", using: :btree
    t.index ["uid", "provider"], name: "index_users_on_uid_and_provider", unique: true, using: :btree
  end

  create_table "users_students", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "student_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  add_foreign_key "authorized_people", "students"
  add_foreign_key "documents", "users"
  add_foreign_key "extracurricular_activities", "academic_levels"
  add_foreign_key "line_items", "orders"
  add_foreign_key "line_items", "products"
  add_foreign_key "medicines", "students"
  add_foreign_key "payments", "orders"
  add_foreign_key "students", "extracurricular_activities"
  add_foreign_key "tutor_reports", "orders"
  add_foreign_key "tutor_reports", "tutors"
  add_foreign_key "tutor_reports", "users"
  add_foreign_key "users", "roles"
end
