class AddConektaIdToOrders < ActiveRecord::Migration[5.0]
  def change
    add_column :orders, :conekta_id, :string
  end
end
