module Swaggers
  module GradeSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/grades' do
        operation :get do
          key :description, 'List of Grades'
          key :operationId, 'Grades'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Grade'
          ]
          parameter do
            key :name, :academic_level_id
            key :in, :query
            key :description, 'ID of Academic level to fetch its grades'
            key :required, false
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Grades List fetched successfully'
            schema do
              key :'$ref', :GradeInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Grade'
          key :operationId, 'Add Grade'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Grade'
          ]
          parameter do
            key :name, 'grade[academic_level_id]'
            key :in, :query 
            key :description, 'Academic Level Id'
            key :required, true
            key :type, :string
            key :'$ref', :GradeInput
          end
          parameter do
            key :name, 'grade[name]'
            key :in, :query 
            key :description, 'Grade Name'
            key :required, false
            key :type, :string
            key :'$ref', :GradeInput
          end
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Grade created successfully'
            schema do
              key :'$ref', :GradeInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/grades/{id}' do
        operation :get do
          key :description, 'Returns a Grade'
          key :operationId, 'find Grade By Id'
          key :tags, [
            'Grade'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Grade to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Grade fetched successfully'
            schema do
              key :'$ref', :GradeInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a Grade '
          key :operationId, 'Update Grade'
          key :tags, [
            'Grade'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Grade to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'grade[academic_level_id]'
            key :in, :query 
            key :description, 'Academic Level Id'
            key :required, false
            key :type, :string
            key :'$ref', :GradeInput
          end
          parameter do
            key :name, 'grade[name]'
            key :in, :query 
            key :description, 'Grade Name'
            key :required, false
            key :type, :string
            key :'$ref', :GradeInput
          end
      
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Grade Updated successfully'
            schema do
              key :'$ref', :GradeInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Grade'
          key :operationId, 'delete Grade'
          key :tags, [
            'Grade'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Grade to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Grade Deleted successfully'
            schema do
              key :'$ref', :GradeInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end
