module Swaggers
  module TutorSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :Tutor do
        key :required, [:id, :name, :last_name, :father_last_name, :mother_last_name, :title, :phone, :cell_phone, :work_phone, :emergency_phone, :email, :rfc, :curp, :first_name, :last_name, :father_last_name, :mother_last_name, :numbers, :created_by, :email, :middle_name, :birthday, :sex, :address_street, :address_colony, :address_number, :address_postal_code, :address_city, :address_state, :control_number, :age, :phone, :cell_phone, :live_with, :type_of_scholarship, :curp, :rfc, :official_docs, :student_picture, :birth_certificate, :curp_document, :proof_of_address]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :name do
          key :type, :string
        end
        property :last_name do
          key :type, :string
        end
        property :father_last_name do
          key :type, :string
        end
        property :mother_last_name do
          key :type, :string
        end
        property :title do
          key :type, :string
        end
        property :phone do
          key :type, :integer
        end
        property :cell_phone do
          key :type, :integer
        end
        property :work_phone do
          key :type, :integer
        end
        property :emergency_phone do
          key :type, :integer
        end
        property :email do
          key :type, :string
        end
        property :rfc do
          key :type, :string
        end
        property :curp do
          key :type, :string
        end
        property :first_name do
          key :type, :string
        end
        property :last_name do
          key :type, :string
        end
        property :father_last_name do
          key :type, :string
        end
        property :mother_last_name do
          key :type, :string
        end
        property :numbers do
          key :type, :string
        end
        property :created_by do
          key :type, :integer
        end
        property :email do
          key :type, :string
        end
        property :middle_name do
          key :type, :string
        end
        property :birthday do
          key :type, :date
        end
        property :sex do
          key :type, :string
        end
        property :address_street do
          key :type, :string
        end
        property :address_colony do
          key :type, :string
        end
        property :address_number do
          key :type, :string
        end
        property :address_postal_code do
          key :type, :string
        end
        property :address_city do
          key :type, :string
        end
        property :address_state do
          key :type, :string
        end
        property :control_number do
          key :type, :integer
        end
        property :age do
          key :type, :integer
        end
        property :phone do
          key :type, :integer
        end
        property :cell_phone do
          key :type, :integer
        end
        property :live_with do
          key :type, :string
        end
        property :type_of_scholarship do
          key :type, :string
        end
        property :curp do
          key :type, :string
        end
        property :rfc do
          key :type, :string
        end
        property :official_docs do
          key :type, :string
        end
        property :student_picture do
          key :type, :string
        end
        property :birth_certificate do
          key :type, :string
        end
        property :curp_document do
          key :type, :string
        end
        property :proof_of_address do
          key :type, :string
        end
      end

      swagger_schema :TutorInput do
        allOf do
          schema do
            key :'$ref', :Tutor
          end
          schema do
            key :required, [:name, :last_name, :father_last_name, :mother_last_name, :title, :phone, :cell_phone, :work_phone, :emergency_phone, :email, :rfc, :curp, :first_name, :last_name, :father_last_name, :mother_last_name, :numbers, :created_by, :email, :middle_name, :birthday, :sex, :address_street, :address_colony, :address_number, :address_postal_code, :address_city, :address_state, :control_number, :age, :phone, :cell_phone, :live_with, :type_of_scholarship, :curp, :rfc, :official_docs, :student_picture, :birth_certificate, :curp_document, :proof_of_address]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end
