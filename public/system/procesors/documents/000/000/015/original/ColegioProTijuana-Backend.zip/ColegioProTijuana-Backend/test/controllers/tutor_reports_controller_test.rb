require 'test_helper'

class TutorReportsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @tutor_report = tutor_reports(:one)
  end

  test "should get index" do
    get tutor_reports_url, as: :json
    assert_response :success
  end

  test "should create tutor_report" do
    assert_difference('TutorReport.count') do
      post tutor_reports_url, params: { tutor_report: {  } }, as: :json
    end

    assert_response 201
  end

  test "should show tutor_report" do
    get tutor_report_url(@tutor_report), as: :json
    assert_response :success
  end

  test "should update tutor_report" do
    patch tutor_report_url(@tutor_report), params: { tutor_report: {  } }, as: :json
    assert_response 200
  end

  test "should destroy tutor_report" do
    assert_difference('TutorReport.count', -1) do
      delete tutor_report_url(@tutor_report), as: :json
    end

    assert_response 204
  end
end
