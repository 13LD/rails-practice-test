class AddGeneralsAndClinicsFieldsToStudents < ActiveRecord::Migration[5.0]
  def change
  	add_column :students, :extra_contact_number, :string
    add_column :students, :extra_contact_email, :string
    add_column :students, :father_name, :string
    add_column :students, :mother_name, :string
    add_column :students, :authorized_persons, :jsonb
    add_column :students, :has_disease, :boolean, default: false
    add_column :students, :disease_name, :string
    add_column :students, :has_allergic, :boolean, default: false
    add_column :students, :allergic_name, :string
    add_column :students, :has_treatment, :boolean, default: false
    add_column :students, :treatment_name, :string
    add_column :students, :doctor_name, :string
    add_column :students, :doctor_number, :string
    add_column :students, :has_to_take_medicine, :boolean, default: false
    add_column :students, :medicines, :jsonb
  end
end
