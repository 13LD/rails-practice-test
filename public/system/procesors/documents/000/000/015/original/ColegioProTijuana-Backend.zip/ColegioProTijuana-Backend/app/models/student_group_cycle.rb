class StudentGroupCycle < ApplicationRecord

  #enum status: [:current, :archieved]
  enum payment_type: [:complete, :installment_ten ,:installment_twelve]
  enum status: [:pre_inscription, :paid, :inscrito, :re_inscription, :inactive]
  belongs_to :student
  belongs_to :group_cycle
  after_commit :update_student_current_detail


  private

  def update_student_current_detail
    cycle = group_cycle.cycle
    group = group_cycle.group
    grade = group.grade
    academic_level = grade.academic_level
    payment_type = self.payment_type
    if student.student_current_detail.present?
      student.student_current_detail.update(:academic_level_name  => academic_level.name, :cycle_name => cycle.name, :grade_name => grade.name, :group_name => group.name, :academic_level_id => academic_level.id ,:cycle_id => cycle.id ,:grade_id => grade.id, :group_id => group.id, :payment_type => payment_type)
    else
      StudentCurrentDetail.create(:academic_level_name  => academic_level.name, :cycle_name => cycle.name, :grade_name => grade.name, :group_name => group.name, :academic_level_id => academic_level.id ,:cycle_id => cycle.id ,:grade_id => grade.id, :group_id => group.id, :payment_type => payment_type, :student_id => student.id)
    end
  end
end
