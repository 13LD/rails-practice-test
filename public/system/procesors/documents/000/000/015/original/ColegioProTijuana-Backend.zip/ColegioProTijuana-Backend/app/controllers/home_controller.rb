class HomeController < ApplicationController
  def index
    redirect_to '/swagger/dist/index.html?url=/apidocs.json'
  end
end

