class StudentCurrentDetail < ApplicationRecord
  belongs_to :academic_level
  belongs_to :cycle
  belongs_to :grade
  belongs_to :group
  belongs_to :student
  enum payment_type: [:complete, :installment_ten ,:installment_twelve]

end
