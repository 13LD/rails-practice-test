class AddGradeIdToGroups < ActiveRecord::Migration[5.0]
  def change
    add_column :groups, :grade_id, :integer
    add_index :groups, :grade_id
  end
end
