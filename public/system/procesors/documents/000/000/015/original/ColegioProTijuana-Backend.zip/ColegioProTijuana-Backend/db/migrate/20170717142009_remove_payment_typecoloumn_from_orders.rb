class RemovePaymentTypecoloumnFromOrders < ActiveRecord::Migration[5.0]
  def change
    remove_column :orders, :payment_type, :string
  end
end
