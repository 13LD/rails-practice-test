class SchoolInformation < ApplicationRecord

  # Validation
  validates :name, presence: true
  validates :sep, presence: true
  validates :fiscal_address, presence: true
  validates :rfc, presence: true
  validates :business_name, presence: true
  validates :phone, presence: true
  validates :emergency_phone, presence: true
  validates :legal_guardian, presence: true

  has_many :users, dependent: :destroy
  has_many :product_types
  has_many :academic_levels, dependent: :destroy

end
