class GroupsController < ApplicationController
  include Swaggers::GroupSwaggers
  before_action :set_group, only: [:show, :update, :destroy]
  before_action :authenticate_user!
    
  # GET /groups
  def index
    if params[:grade_id]
      @grade = Grade.find_by(id: params[:grade_id])
      if @grade
        @academic_level = AcademicLevel.find_by_id(@grade.academic_level_id)
        render_success_response(@grade.groups, :include => {:grade => { :include => {:academic_level => {:only => :name}}, :only => :name}})
      else
        not_found
      end
    else
      @groups = Group.all
      render_success_response(@groups, :include => {:grade => { :include => {:academic_level => {:only => :name}}, :only => :name}})
    end
  end

  # GET /groups/1
  def show
    if @group
      render_success_response(@group, :include => {:grade => { :include => {:academic_level => {:only => :name}}, :only => :name}})
    else
      not_found
    end
  end

  # POST /groups
  def create
    if Grade.exists?(params[:group][:grade_id])
      if params[:group]
        @group = Group.new(group_params)
        if @group.save
          render_success_response(@group, :include => {:grade => { :include => {:academic_level => {:only => :name}}, :only => :name}})
        else
          render_error_message("Group can't be saved", 422)
        end
      else
        render_error_message("Missing Parameters", 422)
      end
    else
      render_error_message("Grade Id doesn't exists", 422)
    end
  end

  # PATCH/PUT /groups/1
  def update
    if Grade.exists?(params[:group][:grade_id])
      if @group 
        @group.update(group_params)
        render_success_response(@group, :include => {:grade => { :include => {:academic_level => {:only => :name}}, :only => :name}})
      else
        not_found
      end
    else
      render_error_message("Grade Id doesn't exists", 422)
    end
  end

  # DELETE /groups/1
  def destroy
    if @group
      @group.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_group
      @group = Group.find_by(id: params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def group_params
      params.require(:group).permit(:name, :grade_id, :maximum_capacity)
    end
end
