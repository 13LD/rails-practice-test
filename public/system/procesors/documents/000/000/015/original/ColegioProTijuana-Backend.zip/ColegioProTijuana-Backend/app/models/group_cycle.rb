class GroupCycle < ApplicationRecord
  belongs_to :group
  belongs_to :cycle

  has_many :student_group_cycles
  has_many :students, through: :student_group_cycles  
end
