class Grade < ApplicationRecord
  belongs_to :academic_level

  # Validation
  validates :name, presence: true

  has_many :groups
  has_many :student_current_details  
end
