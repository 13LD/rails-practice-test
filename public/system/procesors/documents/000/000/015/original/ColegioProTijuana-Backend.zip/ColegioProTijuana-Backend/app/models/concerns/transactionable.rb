module Transactionable
  extend ActiveSupport::Concern

  def total
    line_items.map(&:total).sum
  end


  def amount_paid
    payments.map(&:amount).sum
  end



  def due
    total - amount_paid
  end
end
