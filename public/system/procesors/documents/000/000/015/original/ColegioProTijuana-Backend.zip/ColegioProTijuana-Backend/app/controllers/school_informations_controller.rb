class SchoolInformationsController < ApplicationController
  include Swaggers::SchoolInformationSwaggers
  before_action :set_school_information, only: [:show, :update, :destroy]
  before_action :authenticate_user!

  # GET /school_informations
  def index
    @school_informations = SchoolInformation.all
    render_success_response(@school_informations)
  end

  # GET /school_informations/1
  def show
    if @school_information
      render_success_response(@school_information)
    else
      not_found
    end
  end

  # POST /school_informations
  def create
    if params[:school_information]
      @school_information = SchoolInformation.new(school_information_params)
      if @school_information.save
        render_success_response(@school_information)
      else
        render_error_message("School Information can't be saved", 422)
      end
    else
      render_error_message("Missing Parameters", 422)
    end
  end

  # PATCH/PUT /school_informations/1
  def update
    if @school_information 
      @school_information.update(school_information_params)
      render_success_response(@school_information)
    else
      not_found
    end
  end

  # DELETE /school_informations/1
  def destroy
    if @school_information
      @school_information.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_school_information
      @school_information = SchoolInformation.find_by(id: params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def school_information_params
      params.require(:school_information).permit(:name, :sep, :fiscal_address, :rfc, :business_name, :phone, :emergency_phone, :legal_guardian)
    end
end
