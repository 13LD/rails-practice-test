class PaymentsController < ApplicationController
  include Swaggers::PaymentSwaggers
  before_action :set_payment, only: [:show, :update, :destroy]
  before_action :authenticate_user!
  
  # GET /payments
  def index
    query = ""
    query = "name LIKE '%#{params[:name]}%'" if params[:name]
    @product_types = ProductType.where(query).includes(:payments)
    quantity = @product_types.count
    @results = @product_types&.map do |product_type|
      total = product_type.payments.sum(:amount)
      {:name => product_type.name, :quantity => quantity, :total => total}
    end
    render_success_response(@results)
  end

  # GET /payments/1
  def show
    if @payment
      render_success_response(@payment)
    else
      not_found
    end
  end

  # POST /payments
  def create
    if (Student.exists?(params[:payment][:student_id]) && Order.exists?(params[:payment][:order_id]))
      if params[:payment]
        @order = Order.find_by(id: params[:payment][:order_id])
        @payment = @order.payments.new(payment_params)
        @payment.created_by = current_user.id
        if @payment.save
          if @order.due < 1
            @order.status = 1
            @order.save
          end
          render_success_response(@payment)
        else
          render_error_message("Payment can't be saved", 422)
        end
      else
        render_error_message("Missing Parameters", 422)
      end
    else
      render_error_message("Id's doesn't exists", 422)
    end
  end

  # PATCH/PUT /payments/1
  def update
    if (Student.exists?(params[:payment][:student_id]))
      if @payment
        @payment.update(payment_params)
        render_success_response(@payment)
      else
        not_found
      end
    else
      render_error_message("Id's doesn't exists", 422)
    end
  end

  # DELETE /payments/1
  def destroy
    if @payment
      @payment.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  def change_status_of_student
    product_type = ProductType.find(params[:payment][:product_type_id])
    if product_type.name == 'installment' 
      @student = Student.find(params[:payment][:student_id])
      @student.is_active = 'true'
      @student.save
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_payment
      @payment = Payment.find_by(id: params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def payment_params
      params.require(:payment).permit(:student_id, :tutor_id, :status, :amount, :currency, :exchange_rate, :created_by, :product_type_id, :payment_method_id, :order_id)
    end
end
