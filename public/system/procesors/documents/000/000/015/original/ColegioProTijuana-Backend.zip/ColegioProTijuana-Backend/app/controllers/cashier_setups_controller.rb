class CashierSetupsController < ApplicationController
  include Swaggers::CashierSetupSwaggers
  before_action :set_cashier_setup, only: [:show, :update, :destroy]
  before_action :authenticate_user!

  # GET /cashier_setups
  def index
    if params[:id]
      @cashier_setup = CashierSetup.find_by(id: params[:id])
      if @cashier_setup
        render_success_response(@cashier_setup.to_json)
      else
        not_found
      end
    else
      @cashier_setups = CashierSetup.all
      @results = @cashier_setups&.map do |cashier_setup|
        cashier_setup.to_json
      end
      render_success_response(@results)
    end
  end

  # GET /cashier_setups/1
  def show
    if @cashier_setup
      render_success_response(@cashier_setup)
    else
      not_found
    end
  end

  # POST /cashier_setups
  def create
    if params[:cashier_setup]
      @cashier_setup = CashierSetup.new(cashier_setup_params)
      if @cashier_setup.save
        render_success_response(@cashier_setup.to_json)
      else
        render_error_message("Cashier Setup can't be saved", 422)
      end
    else
      render_error_message("Missing Parameters", 422)
    end
  end

  # PATCH/PUT /cashier_setups/1
  def update
    if @cashier_setup 
      @cashier_setup.update(cashier_setup_params)
      render_success_response(@cashier_setup)
    else
      not_found
    end
  end

  # DELETE /cashier_setups/1
  def destroy
    if @cashier_setup
      @cashier_setup.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_cashier_setup
      @cashier_setup = CashierSetup.find_by(id: params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def cashier_setup_params
      params.require(:cashier_setup).permit(:cashier_cut, :cashier_cut_frequency, :initial_cash, :period, :max_amount)
    end
end
