require 'test_helper'

class CashierSetupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
