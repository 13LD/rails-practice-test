class StudentsController < ApplicationController
  #authorize_resource
  include Swaggers::StudentSwaggers
  before_action :set_student, only: [:show, :update, :destroy]
  before_action :authenticate_user!
  
  # GET /users
  def index
    @students = Student.all
    render_success_response(@students, include: ['tutor', 'student_current_detail', 'student_group_cycles', :medicines, authorized_people: {only: :name}])
  end

  # GET /users/1
  def show
    if @student
      render_success_response(@student, include: ['tutor', 'student_current_detail', 'student_group_cycles', :medicines, authorized_people: {only: :name}])
    else
      not_found
    end
  end

  # POST /users
  def create
    if Tutor.exists?(params[:student][:tutor_id])
      if params[:student]
        @student = Student.new(student_params)
        @student.created_by = current_user.id
        @student.enrollment_number = @student.create_enrollment_number
        if @student.save
          render_success_response(@student)
        else
          render_error_message("Student can't be saved", 422)
        end
      else
        render_error_message("Missing Parameters", 422)
      end
    else
      render_error_message("Tutor Id doesn't exists", 422)
    end
  end

  # PATCH/PUT /users/1
  def update
    if Tutor.exists?(params[:student][:tutor_id])
      if @student 
        @student.update(student_params)
        render_success_response(@student)
      else
        not_found
      end
    else
      render_error_message("Tutor Id doesn't exists", 422)
    end
  end

  # DELETE /users/1
  def destroy
    if @student
      @student.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  def activate
    @student = Student.find(params[:id])
    if @student
      @student.activate_account!
      render :json => { :message => "Activated" }
    else
      render :json => { :errors => "student not found" }
    end
  end

  def deactivate
    @student = Student.find(params[:id])
    if @student
      @student.deactivate_account!
      render :json => { :message => "Deactivated" }
    else
      render :json => { :errors => "student not found" }
    end
  end

  def download_pdf
    arr = ['student_picture', 'birth_certificate', 'curp_document', 'proof_of_address', 'certificate_of_qualifications', 'unsubscribe_folio', 'regulation']
    if arr.include?(params[:document])
      @student = Student.find(params[:id])
      response.headers['Content-Length'] = @student.send(params[:document].to_sym).size.to_s
      send_file("#{@student.send(params[:document].to_sym).path}")
    else
      render :json => { :errors => "Document not found" }
    end
  end

  def delete_pdf
    arr = ['student_picture', 'birth_certificate', 'curp_document', 'proof_of_address', 'certificate_of_qualifications', 'unsubscribe_folio', 'regulation']
    if arr.include?(params[:document])
      @student = Student.find(params[:id])
      if params[:document] == 'student_picture'
        @student.remove_student_picture!
        @student.save
        render_success_response(nil)
      elsif params[:document] == 'birth_certificate'
        @student.remove_birth_certificate!
        @student.save
        render_success_response(nil)
      elsif params[:document] == 'curp_document'
        @student.remove_curp_document!
        @student.save
        render_success_response(nil)
      elsif params[:document] == 'proof_of_address'
        @student.remove_proof_of_address! 
        @student.save
        render_success_response(nil)
      elsif params[:document] == 'certificate_of_qualifications'
        @student.remove_certificate_of_qualifications! 
        @student.save
        render_success_response(nil)
      elsif params[:document] == 'unsubscribe_folio'
        @student.remove_unsubscribe_folio! 
        @student.save
        render_success_response(nil)
      elsif params[:document] == 'regulation'
        @student.remove_regulation! 
        @student.save
        render_success_response(nil)        
      else
        render :json => { :errors => "Wrong Document Type" }
      end
    else
      render :json => { :errors => "Document Not Found" }
    end  
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_student
      @student = Student.find_by(id: params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def student_params
      params.require(:student).permit(
        :email, 
        :first_name, 
        :last_name, 
        :father_last_name, 
        :mother_last_name, 
        :numbers, 
        :created_by, 
        :middle_name, 
        :birthday, 
        :sex, 
        :address_street, 
        :address_colony, 
        :address_number, 
        :address_postal_code, 
        :address_city, 
        :address_state, 
        :control_number, 
        :age, 
        :phone, 
        :cell_phone, 
        :live_with, 
        :type_of_scholarship, 
        :curp, 
        :rfc, 
        :official_docs, 
        :is_active, 
        :tutor_id,
        :extended_time,
        :extracurricular_activity_id,
        :student_picture, 
        :birth_certificate, 
        :curp_document, 
        :proof_of_address,
        :certificate_of_qualifications,
        :unsubscribe_folio,
        :regulation,
        :extra_contact_number,
        :extra_contact_email,
        :father_name,
        :mother_name,
        :authorized_persons,
        :has_disease,
        :disease_name,
        :has_allergic,
        :allergic_name,
        :has_treatment,
        :treatment_name,
        :doctor_name,
        :doctor_number,
        :has_to_take_medicine,
        :medicines
      )
    end
end
