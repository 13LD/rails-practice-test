module Swaggers
  module ProductTypeSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :ProductType do
        key :required, [:id, :name, :description]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :name do
          key :type, :string
        end
        property :description do
          key :type, :text
        end
      end
      
      swagger_schema :ProductTypeInput do
        allOf do
          schema do
            key :'$ref', :ProductType
          end
          schema do
            key :required, [:name, :description]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end