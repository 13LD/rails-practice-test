class AddExtendedTimeToStudent < ActiveRecord::Migration[5.0]
  def change
    add_column :students, :extended_time, :boolean, default: false
    add_reference :students, :extracurricular_activity, foreign_key: true
  end
end
