class AddSchoolInformationIdToProductTypes < ActiveRecord::Migration[5.0]
  def change
    add_column :product_types, :school_information_id, :integer
    add_index :product_types, :school_information_id
  end
end
