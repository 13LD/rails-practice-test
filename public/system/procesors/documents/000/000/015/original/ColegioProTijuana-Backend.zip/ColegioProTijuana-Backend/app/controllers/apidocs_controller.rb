class ApidocsController < ApplicationController
  include Swagger::Blocks
  
  swagger_root do
    key :swagger, '2.0'
    info do
      key :version, '2.0.0'
      key :title, 'Swagger Userstore'
      key :description, 'A sample API that uses a userstore as an example to ' \
                        'demonstrate features in the swagger-2.0 specification'
      key :termsOfService, 'http://helloreverb.com/terms/'
      contact do
        key :name, 'Wordnik API Team'
      end
      license do
        key :name, 'MIT'
      end
    end
    tag do
      key :name, 'User'
      key :description, 'Users operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Allotment'
      key :description, 'Allotment operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Academic level'
      key :description, 'Academic levels operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Extracurricular Activity'
      key :description, 'Extracurricular Activities operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Cycle'
      key :description, 'Cycles operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Group'
      key :description, 'Groups operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Payment method'
      key :description, 'Payment methods operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'School information'
      key :description, 'School informations operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Authorized person'
      key :description, 'Authorized people operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Medicine'
      key :description, 'Medicines operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Student'
      key :description, 'Student operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Tutor'
      key :description, 'Tutor operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Tutor Report'
      key :description, 'Tutor Report operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Roles'
      key :description, 'Roles operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Product'
      key :description, 'Products operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Product Type'
      key :description, 'Product Types operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Grade'
      key :description, 'Grades operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Payment'
      key :description, 'Payments operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Cashier setup'
      key :description, 'Cashier setup operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Order'
      key :description, 'Order operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Line Item'
      key :description, 'Line item operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    tag do
      key :name, 'Notification'
      key :description, 'Notification operations'
      externalDocs do
        key :description, 'Find more info here'
        key :url, 'https://swagger.io'
      end
    end
    key :consumes, ['application/json']
    key :produces, ['application/json']

    security_definition :client do
      key :type, :apiKey
      key :name, :client
      key :in, :header
    end
    security_definition :uid do
      key :type, :apiKey
      key :name, :uid
      key :in, :header
    end
    security_definition 'access-token' do
      key :type, :apiKey
      key :name, 'access-token'
      key :in, :header
    end
    security_definition :userstore_auth do
      key :type, :oauth2
      key :authorizationUrl, 'http://swagger.io/api/oauth/dialog'
      key :flow, :implicit
      scopes do
        key 'write:users', 'modify users in your account'
        key 'read:users', 'read your users'
      end
    end

  end

  # A list of all classes that have swagger_* declarations.
  SWAGGERED_CLASSES = [
    UsersController,
    User,
    AcademicLevelsController,
    AllotmentsController,
    AcademicLevel,
    ExtracurricularActivitiesController,
    ExtracurricularActivity,
    CyclesController,
    Cycle,
    GroupsController,
    Group,
    PaymentMethodsController,
    PaymentMethod,
    SchoolInformationsController,
    SchoolInformation,
    AuthorizedPeopleController,
    AuthorizedPerson,
    MedicinesController,
    Medicine,
    StudentsController,
    Student,
    TutorsController,
    Tutor,
    TutorReportsController,
    TutorReport,
    RolesController,
    Role,
    ProductsController,
    Product,
    ProductTypesController,
    ProductType,
    GradesController,
    Grade,
    PaymentsController,
    Payment,
    CashierSetupsController,
    CashierSetup,
    OrdersController,
    Order,
    LineItemsController,
    LineItem,
    NotificationsController,
    Notification,
    ErrorModel,
    self,
  ].freeze

  def index
    render json: Swagger::Blocks.build_root_json(SWAGGERED_CLASSES)
  end
end
