class AddOrderIdToPaymentMethod < ActiveRecord::Migration[5.0]
  def change
    add_column :payment_methods, :order_id, :integer
    add_index :payment_methods, :order_id
  end
end
