class ExtracurricularActivitiesController < ApplicationController
  include Swaggers::ExtracurricularActivitySwaggers
  before_action :set_extracurricular_activity, only: [:show, :update, :destroy]
  before_action :authenticate_user!

  # GET /extracurricular_activities
  # GET /extracurricular_activities.json
  def index
  	if params[:academic_level_id]
      @academic_level = AcademicLevel.find_by(id: params[:academic_level_id])
      if @academic_level
        render_success_response(@academic_level.extracurricular_activities)
      else
        not_found
      end
    else
      @extracurricular_activities = ExtracurricularActivity.all
      render_success_response(@extracurricular_activities)
    end
  end

  # GET /extracurricular_activities/1
  # GET /extracurricular_activities/1.json
  def show
  	if @extracurricular_activity
      render_success_response(@extracurricular_activity)
    else
      not_found
    end
  end

  # POST /extracurricular_activities
  # POST /extracurricular_activities.json
  def create
  	if AcademicLevel.exists?(params[:extracurricular_activity][:academic_level_id])
      if params[:extracurricular_activity]
        @extracurricular_activity = ExtracurricularActivity.new(extracurricular_activity_params)
        if @extracurricular_activity.save
          render_success_response(@extracurricular_activity)
        else
          render_error_message("Extracurricular activity can't be saved", 422)
        end
      else
        render_error_message("Missing Parameters", 422)
      end
    else
      render_error_message("Academic Level Id doesn't exists", 422)
    end
  end

  # PATCH/PUT /extracurricular_activities/1
  # PATCH/PUT /extracurricular_activities/1.json
  def update
  	if AcademicLevel.exists?(params[:extracurricular_activity][:academic_level_id])
      if @extracurricular_activity 
        @extracurricular_activity.update(extracurricular_activity_params)
        render_success_response(@extracurricular_activity)
      else
        not_found
      end
    else
      render_error_message("Academic Level Id doesn't exists", 422)
    end
    # if @extracurricular_activity.update(extracurricular_activity_params)
    #   render json: @extracurricular_activity, status: :ok, location: @extracurricular_activity
    # else
    #   render json: @extracurricular_activity.errors, status: :unprocessable_entity
    # end
  end

  # DELETE /extracurricular_activities/1
  # DELETE /extracurricular_activities/1.json
  def destroy
    if @extracurricular_activity
      @extracurricular_activity.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_extracurricular_activity
      @extracurricular_activity = ExtracurricularActivity.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def extracurricular_activity_params
      params.require(:extracurricular_activity).permit(:name ,:description, :academic_level_id)
    end
end
