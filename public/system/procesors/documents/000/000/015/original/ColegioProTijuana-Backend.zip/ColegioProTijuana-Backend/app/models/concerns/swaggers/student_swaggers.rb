module Swaggers
  module StudentSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :Student do
        key :required, [:id, :first_name, :last_name, :father_last_name, :mother_last_name, :numbers, :created_by, :email, :middle_name, :birthday, :sex, :address_street, :address_colony, :address_number, :address_postal_code, :address_city, :address_state, :control_number, :age, :phone, :cell_phone, :live_with, :type_of_scholarship, :curp, :rfc, :official_docs, :student_picture, :birth_certificate, :curp_document, :proof_of_address]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :first_name do
          key :type, :string
        end
        property :last_name do
          key :type, :string
        end
        property :father_last_name do
          key :type, :string
        end
        property :mother_last_name do
          key :type, :string
        end
        property :numbers do
          key :type, :string
        end
        property :created_by do
          key :type, :integer
        end
        property :email do
          key :type, :string
        end
        property :middle_name do
          key :type, :string
        end
        property :birthday do
          key :type, :date
        end
        property :sex do
          key :type, :string
        end
        property :address_street do
          key :type, :string
        end
        property :address_colony do
          key :type, :string
        end
        property :address_number do
          key :type, :string
        end
        property :address_postal_code do
          key :type, :string
        end
        property :address_city do
          key :type, :string
        end
        property :address_state do
          key :type, :string
        end
        property :control_number do
          key :type, :integer
        end
        property :age do
          key :type, :integer
        end
        property :phone do
          key :type, :integer
        end
        property :cell_phone do
          key :type, :integer
        end
        property :live_with do
          key :type, :string
        end
        property :type_of_scholarship do
          key :type, :string
        end
        property :curp do
          key :type, :string
        end
        property :rfc do
          key :type, :string
        end
        property :official_docs do
          key :type, :string
        end
        property :student_picture do
          key :type, :string
        end
        property :birth_certificate do
          key :type, :string
        end
        property :curp_document do
          key :type, :string
        end
        property :proof_of_address do
          key :type, :string
        end
        property :extra_contact_number do
          key :type, :string
        end
        property :extra_contact_email do
          key :type, :string
        end
        property :father_name do
          key :type, :string
        end
        property :mother_name do
          key :type, :string
        end
        property :authorized_persons do
          key :type, :array
        end
        property :has_disease do
          key :type, :boolean
        end
        property :disease_name do
          key :type, :string
        end
        property :has_allergic do
          key :type, :boolean
        end
        property :allergic_name do
          key :type, :string
        end
        property :has_treatment do
          key :type, :boolean
        end
        property :treatment_name do
          key :type, :string
        end
        property :doctor_name do
          key :type, :string
        end
        property :doctor_number do
          key :type, :string
        end
        property :has_to_take_medicine do
          key :type, :boolean
        end
        property :medicines do
          key :type, :array
        end
      end

      swagger_schema :StudentInput do
        allOf do
          schema do
            key :'$ref', :Student
          end
          schema do
            key :required, [:first_name, :last_name, :father_last_name, :mother_last_name, :numbers, :created_by, :email, :middle_name, :birthday, :sex, :address_street, :address_colony, :address_number, :address_postal_code, :address_city, :address_state, :control_number, :age, :phone, :cell_phone, :live_with, :type_of_scholarship, :curp, :rfc, :official_docs, :student_picture, :birth_certificate, :curp_document, :proof_of_address,:extra_contact_number, :extra_contact_email, :father_name, :mother_name, :authorized_persons, :has_disease, :disease_name, :has_allergic, :allergic_name, :has_treatment, :treatment_name, :doctor_name, :doctor_number, :has_to_take_medicine, :medicines]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end
