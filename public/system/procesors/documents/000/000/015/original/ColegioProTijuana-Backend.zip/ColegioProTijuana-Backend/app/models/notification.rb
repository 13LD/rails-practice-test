class Notification < ApplicationRecord

  # Validation
  validates :message, presence: true

end
