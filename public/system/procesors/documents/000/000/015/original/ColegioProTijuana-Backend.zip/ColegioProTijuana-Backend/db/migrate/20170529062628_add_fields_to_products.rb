class AddFieldsToProducts < ActiveRecord::Migration[5.0]
  def change
    add_column :products, :price, :integer
    add_column :products, :product_type, :string
    add_column :products, :taxable, :boolean
  end
end
