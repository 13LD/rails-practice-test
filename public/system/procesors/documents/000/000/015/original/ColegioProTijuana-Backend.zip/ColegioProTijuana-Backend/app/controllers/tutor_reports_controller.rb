class TutorReportsController < ApplicationController
  include Swaggers::TutorReportSwaggers
  before_action :set_tutor_report, only: [:show, :update, :destroy]
  before_action :authenticate_user!

  # GET /tutor_reports
  # GET /tutor_reports.json
  def index
    if params[:user_id]
      @user = User.find_by(id: params[:user_id])
      if @user
        render_success_response(@user.tutor.tutor_reports)
      else
        not_found
      end
    else
      @tutor_reports = TutorReport.all
      render_success_response(@tutor_reports)
    end
  end

  # GET /tutor_reports/1
  # GET /tutor_reports/1.json
  def show
    if @tutor_report
      render_success_response(@tutor_report)
    else
      not_found
    end
  end

  # POST /tutor_reports
  # POST /tutor_reports.json
  def create
    if current_user
      @user = current_user
      @tutor = Tutor.find_by(user_id: @user.id)
      if params[:tutor_report][:order_id]
        @order = Order.find_by(id: params[:tutor_report][:order_id])
      else
        @order = Order.last.where(user_id: @user.id)
      end
      @payments = Payment.all.where(tutor_id: @tutor.id)

      @tutor_report = TutorReport.new(
        :tutor_name => @tutor.full_name,
        :tutor_curp => @tutor.curp,
        :tutor_email => @tutor.email,
        :tutor_id => @tutor.id,
        :user_id => @user.id,
        :order_id => @order.id,
        :amount_paid => @order.amount_paid,
        :pending_amount => @order.due,
        :funded => @order.amount_paid,
        :total_amount => @order.amount_paid + @order.due
      )
      if @tutor_report.save
        render_success_response(@tutor_report)
      else
        render_error_message("Tutor report can't be saved", 422)
      end
    end
  end

  # PATCH/PUT /tutor_reports/1
  # PATCH/PUT /tutor_reports/1.json
  def update
    if @tutor_report.update(tutor_report_params)
      render_success_response(@tutor_report)
    else
      render_error_message("Tutor report can't be saved", 422)
    end
  end

  # DELETE /tutor_reports/1
  # DELETE /tutor_reports/1.json
  def destroy
    if @tutor_report
      @tutor_report.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_tutor_report
      @tutor_report = TutorReport.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def tutor_report_params
      params.require(:tutor_report).permit(:tutor_name,
                                           :tutor_curp,
                                           :tutor_email,
                                           :tutor_id,
                                           :user_id,
                                           :payment_type,
                                           :order_id,
                                           :amount_paid,
                                           :funded,
                                           :pending_amount,
                                           :total_amount
      )
    end
end
