class AddFieldToStudents < ActiveRecord::Migration[5.0]
  def change
    add_column :students, :numbers, :string
  end
end
