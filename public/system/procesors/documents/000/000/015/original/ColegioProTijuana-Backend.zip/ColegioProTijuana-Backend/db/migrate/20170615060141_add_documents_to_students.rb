class AddDocumentsToStudents < ActiveRecord::Migration[5.0]
  def change
     add_column :students, :student_picture, :string
     add_column :students, :birth_certificate, :string
     add_column :students, :curp_document, :string
     add_column :students, :proof_of_address, :string
  end
end
