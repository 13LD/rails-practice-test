class AddFieldsToPayment < ActiveRecord::Migration[5.0]
  def change
    add_column :payments, :currency, :string, null: false, default: "MXN"
    add_column :payments, :exchange_rate, :decimal, precision: 6, scale: 3, default: 0
  end
end
