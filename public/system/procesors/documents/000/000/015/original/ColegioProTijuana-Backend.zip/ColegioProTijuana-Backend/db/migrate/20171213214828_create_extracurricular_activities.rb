class CreateExtracurricularActivities < ActiveRecord::Migration[5.0]
  def change
    create_table :extracurricular_activities do |t|
      t.string :name
      t.string :description
      t.belongs_to :academic_level, foreign_key: true

      t.timestamps
    end
  end
end
