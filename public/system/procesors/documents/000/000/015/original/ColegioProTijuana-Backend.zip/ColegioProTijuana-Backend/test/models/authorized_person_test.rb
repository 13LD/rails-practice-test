require 'test_helper'

class AuthorizedPersonTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
