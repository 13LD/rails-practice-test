class ProductType < ApplicationRecord

  # Validation
  validates :name, presence: true
  validates :description, presence: true

  has_many :products, dependent: :destroy
  belongs_to :school_information
  has_many :payments,dependent: :destroy
end
