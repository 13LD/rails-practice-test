module Swaggers
  module OrderSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :Order do
        key :required, [:id, :name, :amount, :quantity, :payment_type]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :name do
          key :type, :string
        end
        property :amount do
          key :type, :integer
        end
        property :quantity do
          key :type, :integer
        end
        property :payment_type do
          key :type, :integer
        end
      end

      swagger_schema :OrderInput do
        allOf do
          schema do
            key :'$ref', :Order
          end
          schema do
            key :required, [:name, :amount, :quantity, :payment_type]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end