module Swaggers
  module LineItemSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/line_items' do
        operation :get do
          key :description, 'List of Line items'
          key :operationId, 'Line items'
          key :produces, [
              'application/json'
          ]
          key :tags, [
              'Line Item'
          ]
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Line items List fetched successfully'
            schema do
              key :'$ref', :LineItemInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Line items'
          key :operationId, 'Add Line item'
          key :produces, [
              'application/json'
          ]
          key :tags, [
              'Line Item'
          ]

          parameter do
            key :name, 'line_item[product_id]'
            key :in, :query
            key :description, 'Choose product'
            key :required, false
            key :type, :integer
            key :'$ref', :LineItemInput
          end
          parameter do
            key :name, 'line_item[quantity]'
            key :in, :query
            key :description, 'Line Item quantity'
            key :required, false
            key :type, :integer
            key :'$ref', :LineItemInput
          end
          parameter do
            key :name, 'line_item[discount]'
            key :in, :query
            key :description, 'Line item discount'
            key :required, false
            key :type, :float
            key :'$ref', :LineItemInput
          end
          parameter do
            key :name, 'line_item[order_id]'
            key :in, :query
            key :description, 'Line Item Order'
            key :required, false
            key :type, :integer
            key :'$ref', :LineItemInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Payment method created successfully'
            schema do
              key :'$ref', :LineItemInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end
      swagger_path '/line_items/{id}' do
        operation :get do
          key :description, 'Returns a line items'
          key :operationId, 'find Line item By Id'
          key :tags, [
              'Line Item'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of line item to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Group fetched successfully'
            schema do
              key :'$ref', :LineItemInputInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a line item '
          key :operationId, 'Update line item'
          key :tags, [
              'Line Item'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of line item to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'line_item[product_name]'
            key :in, :query
            key :description, 'Product Name'
            key :required, false
            key :type, :string
            key :'$ref', :LineItemInput
          end
          parameter do
            key :name, 'line_item[product_id]'
            key :in, :query
            key :description, 'Choose product'
            key :required, false
            key :type, :integer
            key :'$ref', :LineItemInput
          end
          parameter do
            key :name, 'line_item[quantity]'
            key :in, :query
            key :description, 'Line Item quantity'
            key :required, false
            key :type, :integer
            key :'$ref', :LineItemInput
          end
          parameter do
            key :name, 'line_item[order_id]'
            key :in, :query
            key :description, 'Line Item Order'
            key :required, false
            key :type, :integer
            key :'$ref', :LineItemInput
          end
          parameter do
            key :name, 'line_item[unit_price]'
            key :in, :query
            key :description, 'Line item unit price'
            key :required, false
            key :type, :float
            key :'$ref', :LineItemInput
          end
          parameter do
            key :name, 'line_item[discount]'
            key :in, :query
            key :description, 'Line item discount'
            key :required, false
            key :type, :float
            key :'$ref', :LineItemInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Line Item Updated successfully'
            schema do
              key :'$ref', :GroupInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete line item'
          key :operationId, 'delete line item'
          key :tags, [
              'Line Item'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of line item to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Line item Deleted successfully'
            schema do
              key :'$ref', :LineItemInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end