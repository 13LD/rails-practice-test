module Swaggers
  module ProductTypeSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/product_types' do
        operation :get do
          key :description, 'List of Product Types'
          key :operationId, 'Product Types'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Product Type'
          ]
          parameter do
            key :name, :school_information_id
            key :in, :query
            key :description, 'ID of School Information to fetch its Product types'
            key :required, false
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Product Types List fetched successfully'
            schema do
              key :'$ref', :ProductTypeInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Product Type'
          key :operationId, 'Add Product Type'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Product Type'
          ]
          parameter do
            key :name, 'product_type[school_information_id]'
            key :in, :query 
            key :description, 'School Information Id'
            key :required, true
            key :type, :string
            key :'$ref', :ProductTypeInput
          end
          parameter do
            key :name, 'product_type[name]'
            key :in, :query 
            key :description, 'Product Type Name'
            key :required, false
            key :type, :string
            key :'$ref', :ProductTypeInput
          end
          parameter do
            key :name, 'product_type[description]'
            key :in, :query 
            key :description, 'Product Description'
            key :required, false
            key :type, :text
            key :'$ref', :ProductTypeInput
          end
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Product Type created successfully'
            schema do
              key :'$ref', :ProductTypeInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/product_types/{id}' do
        operation :get do
          key :description, 'Returns a Product Type'
          key :operationId, 'find Product Type By Id'
          key :tags, [
            'Product Type'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Product Type to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Product Type fetched successfully'
            schema do
              key :'$ref', :ProductTypeInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a Product Type '
          key :operationId, 'Update Product Type'
          key :tags, [
            'Product Type'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Product Type to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'product_type[school_information_id]'
            key :in, :query 
            key :description, 'School Information Id'
            key :required, false
            key :type, :string
            key :'$ref', :ProductTypeInput
          end
          parameter do
            key :name, 'product_type[name]'
            key :in, :query 
            key :description, 'Product Name'
            key :required, false
            key :type, :string
            key :'$ref', :ProductTypeInput
          end
          parameter do
            key :name, 'product_type[description]'
            key :in, :query 
            key :description, 'Product Description'
            key :required, false
            key :type, :text
            key :'$ref', :ProductTypeInput
          end
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Product Type Updated successfully'
            schema do
              key :'$ref', :ProductTypeInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Product Type'
          key :operationId, 'delete Product Type'
          key :tags, [
            'Product Type'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Product Type to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Product Type Deleted successfully'
            schema do
              key :'$ref', :ProductTypeInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end
