class AcademicLevel < ApplicationRecord
  include Swaggers::AcademicLevelSwaggers

  # Validation
  validates :name, presence: true
  validates :incorporation_number, presence: true
  validates :Key, presence: true

  belongs_to :school_information
  has_many :grades, dependent: :destroy
  has_many :student_current_details
end
