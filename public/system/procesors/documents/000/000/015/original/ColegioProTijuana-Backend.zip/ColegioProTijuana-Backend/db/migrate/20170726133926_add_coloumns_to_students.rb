class AddColoumnsToStudents < ActiveRecord::Migration[5.0]
  def change
    add_column :students, :address_street, :string
    add_column :students, :address_colony, :string
    add_column :students, :address_number, :string
    add_column :students, :address_postal_code, :string
    add_column :students, :address_city, :string
    add_column :students, :address_state, :string
  end
end
