class AddSchoolInformationIdToUsers < ActiveRecord::Migration[5.0]
  def change
    add_column :users, :school_information_id, :integer
    add_index :users, :school_information_id
  end
end
