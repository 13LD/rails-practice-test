module Swaggers
  module CycleSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/cycles' do
        operation :get do
          key :description, 'List of Cycles'
          key :operationId, 'Cycles'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Cycle'
          ]
        
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Cycles List fetched successfully'
            schema do
              key :'$ref', :CycleInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Cycle'
          key :operationId, 'Add Cycle'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Cycle'
          ]

          parameter do
            key :name, 'cycle[number]'
            key :in, :query 
            key :description, 'Cycle Number'
            key :required, false
            key :type, :integer
            key :'$ref', :CycleInput
          end
          parameter do
            key :name, 'cycle[start_date]'
            key :in, :query
            key :description, 'Start date'
            key :required, false
            key :type, :date
            key :'$ref', :CycleInput
          end
          parameter do
            key :name, 'cycle[end_date]'
            key :in, :query
            key :description, 'End date'
            key :required, false
            key :type, :date
            key :'$ref', :CycleInput
          end
          parameter do
            key :name, 'cycle[status]'
            key :in, :query
            key :description, 'Status of cycle'
            key :required, false
            key :type, :string
            key :'$ref', :CycleInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Cycle created successfully'
            schema do
              key :'$ref', :CycleInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/cycles/{id}' do
        operation :get do
          key :description, 'Returns a cycle'
          key :operationId, 'find Cycle By Id'
          key :tags, [
            'Cycle'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of cycle to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Cycle fetched successfully'
            schema do
              key :'$ref', :CycleInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a cycle '
          key :operationId, 'Update cycle'
          key :tags, [
            'Cycle'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of cycle to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'cycle[number]'
            key :in, :query 
            key :description, 'Cycle Number'
            key :required, false
            key :type, :integer
            key :'$ref', :CycleInput
          end
          parameter do
            key :name, 'cycle[start_date]'
            key :in, :query
            key :description, 'Start date'
            key :required, false
            key :type, :date
            key :'$ref', :CycleInput
          end
          parameter do
            key :name, 'cycle[end_date]'
            key :in, :query
            key :description, 'End date'
            key :required, false
            key :type, :date
            key :'$ref', :CycleInput
          end
          parameter do
            key :name, 'cycle[status]'
            key :in, :query
            key :description, 'Status of cycle'
            key :required, false
            key :type, :string
            key :'$ref', :CycleInput
          end
      
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Cycle Updated successfully'
            schema do
              key :'$ref', :CycleInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete cycle'
          key :operationId, 'delete cycle'
          key :tags, [
            'Cycle'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of cycle to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Cycle Deleted successfully'
            schema do
              key :'$ref', :CycleInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end

      swagger_path '/update_cycle_and_student_status/{id}' do
        operation :put do
          key :description, 'Update a cycle '
          key :operationId, 'Update cycle'
          key :tags, [
            'Cycle'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of cycle to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'cycle[status]'
            key :in, :query
            key :description, 'Status of cycle'
            key :required, false
            key :type, :string
            key :'$ref', :CycleInput
          end
      
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Cycle Updated successfully'
            schema do
              key :'$ref', :CycleInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end
    end
  end
end