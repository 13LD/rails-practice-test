class StudentsGroup < ApplicationRecord
end
