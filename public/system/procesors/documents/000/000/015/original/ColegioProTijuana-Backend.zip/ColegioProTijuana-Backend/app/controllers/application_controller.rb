class ApplicationController < ActionController::API
  include DeviseTokenAuth::Concerns::SetUserByToken
  include ApiResponder
  
  rescue_from CanCan::AccessDenied do |exception|
    redirect_to root_path, :alert => exception.message
  end
  
  def add_cors_headers
   if params[:token].present? && params[:token] == "i2EHk22wu2tVmLU86lvCfg"
     origin = request.headers["Origin"]
     #unless (not origin.nil?) and (origin == "http://localhost" or origin.starts_with? "http://localhost:")
     #  origin = "http://localhost"
     #end
     headers['Access-Control-Allow-Origin'] = origin
     headers['Access-Control-Allow-Methods'] = '*'
     allow_headers = request.headers["Access-Control-Request-Headers"]
     if allow_headers.nil?
       allow_headers = 'Origin, Authorization, Accept, Content-Type'
     end
     headers['Access-Control-Allow-Headers'] = allow_headers
     headers['Access-Control-Allow-Credentials'] = 'true'
     headers['Access-Control-Max-Age'] = '1728000'
   end
 end

  def not_found
    render_errors_response('Record Not Found', 404)
  end

  def render_json message, code, data_hash=nil
    success = code == 200 ? true : false
    if data_hash.blank?
      render json: {success: success, message: message}, status: code
    else
      render json: {success: success, message: message, data: data_hash}, status: code
    end
  end
end
