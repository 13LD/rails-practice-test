module Swaggers
  module CycleSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :Cycle do
        key :required, [:id, :number, :start_date, :end_date, :status]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :number do
          key :type, :integer
        end
        property :start_date do
          key :type, :date
        end
        property :end_date do
          key :type, :date
        end
        property :status do
          key :type, :string
        end
      end

      swagger_schema :CycleInput do
        allOf do
          schema do
            key :'$ref', :Cycle
          end
          schema do
            key :required, [:number, :start_date, :end_date, :status]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end