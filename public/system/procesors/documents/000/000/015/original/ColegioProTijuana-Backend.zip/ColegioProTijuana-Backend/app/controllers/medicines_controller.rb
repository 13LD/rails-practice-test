class MedicinesController < ApplicationController
  include Swaggers::MedicineSwaggers
  before_action :set_medicine, only: [:show, :update, :destroy]
  before_action :authenticate_user!
  # GET /medicines
  # GET /medicines.json
  def index
    @medicines = Medicine.all
  end

  # GET /medicines/1
  # GET /medicines/1.json
  def show
  end

  # POST /medicines
  # POST /medicines.json
  def create
    @medicine = Medicine.new(medicine_params)

    if @medicine.save
      render json: @medicine, status: :created
    else
      render json: @medicine.errors, status: :unprocessable_entity
    end
  end
  def medicines_list
    statuses = []
    if params[:student_id]
      @student = Student.find_by(id: params[:student_id])
      Medicine.where(student_id: @student.id).destroy_all
    end  
    params[:medicines_list].each do |medicine_params|
      auth = Medicine.new(select_permited(medicine_params))
      statuses << ( auth.save ? "OK" : medicine.errors )
    end if params[:medicines_list]
    render json: statuses
  end 

  # PATCH/PUT /medicines/1
  # PATCH/PUT /medicines/1.json
  def update
    if @medicine.update(medicine_params)
      render json: @medicine
    else
      render json: @medicine.errors, status: :unprocessable_entity
    end
  end

  # DELETE /medicines/1
  # DELETE /medicines/1.json
  def destroy
    @medicine.destroy
  end

  private
    def select_permited(medicine_params)
      medicine_params.permit(:name, :student_id)
    end
    # Use callbacks to share common setup or constraints between actions.
    def set_medicine
      @medicine = Medicine.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def medicine_params
      params.require(:medicine).permit(:name, :student_id)
    end
end
