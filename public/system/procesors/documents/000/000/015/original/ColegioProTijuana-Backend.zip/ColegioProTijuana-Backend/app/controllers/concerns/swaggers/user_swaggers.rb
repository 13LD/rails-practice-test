module Swaggers
  module UserSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/auth' do
        operation :post do
          key :description, 'User Sign Up'
          key :operationId, 'User Sign Up'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'User'
          ]
          parameter do
            key :name, 'user[school_information_id]'
            key :in, :query 
            key :description, 'School Information Id'
            key :required, true
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[name]'
            key :in, :query 
            key :description, 'User Name'
            key :required, false
            key :type, :true
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[email]'
            key :in, :query
            key :description, 'email'
            key :required, true
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[nickname]'
            key :in, :query
            key :description, 'nickname'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[password]'
            key :in, :query
            key :description, 'password'
            key :required, true
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[password_confirmation]'
            key :in, :query
            key :description, 'password_confirmation'
            key :required, true
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[position]'
            key :in, :query
            key :description, 'Position'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[user]'
            key :in, :query
            key :description, 'User'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[area]'
            key :in, :query
            key :description, 'Area'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[active]'
            key :in, :query
            key :description, 'Active'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'User created successfully'
            schema do
              key :'$ref', :UserInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/auth/sign_in' do
        operation :post do
          key :description, 'User SignIn'
          key :operationId, 'User SignIn'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'User'
          ]
          parameter do
            key :name, :email
            key :in, :query
            key :description, 'email'
            key :required, true
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, :password
            key :in, :query
            key :description, 'password'
            key :required, true
            key :type, :string
            key :'$ref', :UserInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          
          response 200 do
            key :description, 'Users successfully Logged In.'
            schema do
              key :'$ref', :UserInput
            end
          end
        end
      end

      swagger_path '/auth/sign_out' do
        operation :delete do
          key :description, 'User SignOut'
          key :operationId, 'User SignOut'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'User'
          ]
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          
          response 200 do
            key :description, 'Users successfully Logged Out.'
            schema do
              key :'$ref', :UserInput
            end
          end
        end
      end

      swagger_path '/users' do
        operation :get do
          key :description, 'List of Users'
          key :operationId, 'Users'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'User'
          ]
           parameter do
            key :name, :school_information_id
            key :in, :query
            key :description, 'ID of School Information to fetch its users'
            key :required, false
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Users List fetched successfully'
            schema do
              key :'$ref', :UserInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end

        operation :post do
          key :description, 'Creates a New User'
          key :operationId, 'Creates a New User'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'User'
          ]
          parameter do
            key :name, 'user[school_information_id]'
            key :in, :query 
            key :description, 'School Information Id'
            key :required, true
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[name]'
            key :in, :query 
            key :description, 'User Name'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[email]'
            key :in, :query
            key :description, 'email'
            key :required, true
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[nickname]'
            key :in, :query
            key :description, 'nickname'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[password]'
            key :in, :query
            key :description, 'password'
            key :required, true
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[password_confirmation]'
            key :in, :query
            key :description, 'password_confirmation'
            key :required, true
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[position]'
            key :in, :query
            key :description, 'Position'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[user]'
            key :in, :query
            key :description, 'User'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[area]'
            key :in, :query
            key :description, 'Area'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[active]'
            key :in, :query
            key :description, 'Active'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'User created successfully'
            schema do
              key :'$ref', :UserInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/users/{id}' do
        operation :get do
          key :description, 'Returns a single user if the user has access'
          key :operationId, 'findUserById'
          key :tags, [
            'User'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of user to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'User fetched successfully'
            schema do
              key :'$ref', :UserInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a user if the user has access'
          key :operationId, 'Update user'
          key :tags, [
            'User'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of user to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'user[school_information_id]'
            key :in, :query 
            key :description, 'School Information Id'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[name]'
            key :in, :query 
            key :description, 'User Name'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[email]'
            key :in, :query
            key :description, 'email'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[nickname]'
            key :in, :query
            key :description, 'nickname'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[password]'
            key :in, :query
            key :description, 'password'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[password_confirmation]'
            key :in, :query
            key :description, 'password_confirmation'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[position]'
            key :in, :query
            key :description, 'position'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[user]'
            key :in, :query
            key :description, 'user'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[area]'
            key :in, :query
            key :description, 'Area'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
          parameter do
            key :name, 'user[active]'
            key :in, :query
            key :description, 'Active'
            key :required, false
            key :type, :string
            key :'$ref', :UserInput
          end
      
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'User Updated successfully'
            schema do
              key :'$ref', :UserInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete user'
          key :operationId, 'delete user'
          key :tags, [
            'User'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of user to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'User Deleted successfully'
            schema do
              key :'$ref', :UserInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end


      swagger_path '/update_role/{id}' do
        operation :put do
          key :description, 'Update a user if the user has access'
          key :operationId, 'Update user'
          key :tags, [
            'User'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of user to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'user[role]'
            key :in, :query 
            key :description, 'User role - id: 1 = User; id: 2 = Admin'
            key :required, false
            key :type, :integer
            key :'$ref', :UserInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'User Updated successfully'
            schema do
              key :'$ref', :UserInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end
    end
  end
end
