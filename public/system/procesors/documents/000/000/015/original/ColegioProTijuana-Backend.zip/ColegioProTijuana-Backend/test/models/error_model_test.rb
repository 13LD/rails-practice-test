require 'test_helper'

class ErrorModelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
