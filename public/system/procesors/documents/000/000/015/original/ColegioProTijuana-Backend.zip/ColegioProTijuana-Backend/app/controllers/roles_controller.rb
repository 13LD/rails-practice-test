class RolesController < ApplicationController
  include Swaggers::RoleSwaggers
  before_action :set_role, only: [:show, :update, :destroy]
  before_action :authenticate_user!
  
  # GET /roles
  def index
    @roles = Role.all
    render_success_response(@roles, include: ['user'])
  end

  # GET /roles/1
  def show
    if @role
      render_success_response(@role, include: ['user'])
    else
      not_found
    end
  end

  def create
    if User.exists?(params[:role][:user_id])
      @user = User.find_by_id(params[:role][:user_id])
      @role = Role.new(role_params)
      if @role.save
        render_success_response(@role, include: ['user'])
      else
        not_found
      end
    else
      render_error_message("User Id doesn't exists", 422)
    end
  end

  # PATCH/PUT /roles/1
  def update
    if User.exists?(params[:role][:user_id])
      if @role 
        @role.update(role_params)
        render_success_response(@role, include: ['user'])
      else
        not_found
      end
    else
      render_error_message("User Id doesn't exists", 422)
    end
  end

  # DELETE /roles/1
  def destroy
    if @role
      @role.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_role
      @role = Role.find_by(id: params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def role_params
      params.require(:role).permit(:role_type, :user_id, :name, :description)
    end
end
