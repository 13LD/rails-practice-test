class Tutor < ApplicationRecord
  before_create :create_user
  after_create :register_with_customer_conekta
  belongs_to :user
  has_many :students
  accepts_nested_attributes_for :students

  # Validation
  validates :name, presence: true
  validates :last_name, presence: true
  validates :father_last_name, presence: true
  validates :mother_last_name, presence: true
  validates :title, presence: true
  validates :phone, presence: true
  validates :cell_phone, presence: true
  validates :work_phone, presence: true
  validates :emergency_phone, presence: true
  validates :email, presence: true
  validates :rfc, presence: true
  validates :curp, presence: true

  def create_user
    user = User.new
    user.name = self.name
    user.email = self.email
    user.password = 12345678
    user.password_confirmation = 12345678
    user.school_information_id = 2
    user.save(validate: false)
    self.user_id = user.id
  end

  def register_with_customer_conekta
    customer = CustomerConektaService.new(user).create_customer
    user.update_attributes(customer_id: customer["id"])
  end

  def full_name
    "#{name} #{last_name}"
  end
end
