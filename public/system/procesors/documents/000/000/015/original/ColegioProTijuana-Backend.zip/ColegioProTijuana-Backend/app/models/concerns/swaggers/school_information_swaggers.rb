module Swaggers
  module SchoolInformationSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :SchoolInformation do
        key :required, [:id, :name, :sep, :fiscal_address, :rfc, :business_name, :phone, :emergency_phone, :legal_guardian]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :name do
          key :type, :string
        end
        property :sep do
          key :type, :string
        end
        property :fiscal_address do
          key :type, :string
        end
        property :rfc do
          key :type, :string
        end
        property :business_name do
          key :type, :string
        end
        property :phone do
          key :type, :integer
        end
        property :emergency_phone do
          key :type, :integer
        end
        property :legal_guardian do
          key :type, :string
        end
      end

      swagger_schema :SchoolInformationInput do
        allOf do
          schema do
            key :'$ref', :SchoolInformation
          end
          schema do
            key :required, [:name, :sep, :fiscal_address, :rfc, :business_name, :phone, :emergency_phone, :legal_guardian]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end