class AddFilesUploadersToStudent < ActiveRecord::Migration[5.0]
  def change
    add_column :students, :certificate_of_qualifications, :string
    add_column :students, :unsubscribe_folio, :string
    add_column :students, :regulation, :string
  end
end
