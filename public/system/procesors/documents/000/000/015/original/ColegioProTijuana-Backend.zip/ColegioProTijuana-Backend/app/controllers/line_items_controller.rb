class LineItemsController < ApplicationController
  include Swaggers::LineItemSwaggers

  before_action :set_line_item, only: [:show, :update, :destroy]

  # GET /line_items
  # GET /line_items.json
  def index
    @line_items = LineItem.all
    render_success_response(@line_items)
  end

  # GET /line_items/1
  # GET /line_items/1.json
  def show
    if @line_item
      render_success_response(@line_item)
    else
      not_found
    end
  end

  # POST /line_items
  # POST /line_items.json
  def create
    if params[:line_item][:order_id]
      @order = Order.find_by(id: params[:line_item][:order_id])
      if params[:line_item][:product_id]
        @product = Product.find_by(id: params[:line_item][:product_id])
        @line_item = @order.line_items.new(
          product_name: @product.name,
          quantity: params[:line_item][:quantity],
          unit_price: @product.price,
          discount: params[:discount],
          order_id: @order.id,
          product_id: @product.id
        )
        if @line_item.save
          @order.amount = @order.amount + @line_item.total
          @order.save
          if !@order.conekta_id.nil?
            order_conekta = Conekta::Order.find(@order.conekta_id)
            @product = Product.find_by(id: params[:line_item][:product_id])
            puts order_conekta
            line_item = order_conekta.line_items.first

            # {
            #     :id => "line_item_2fw8EWJusiRrxdPzR",
            #     :object => "line_item",
            #     :name => "Box of Cohiba S1s",
            #     :unit_price => 35000,
            #     :quantity => 1,
            #     :parent_id => "ord_2fw8EWJusiRrxdPzT",
            #     :antifraud_info => {},
            #     :metadata => {}
            # }
          end
          render_success_response(@line_item)
        else
          render_error_message("Line item can't be saved", 422)
        end
      else
        not_found
      end
    else
      not_found
    end

  end

  # PATCH/PUT /line_items/1
  # PATCH/PUT /line_items/1.json
  def update
    @order.amount = @order.amount - @line_item.total
    @order.save
    if @line_item.update(line_item_params)
      @order.amount = @order.amount + @line_item.total
      @order.save
      render_success_response(@line_item)
    else
      render_error_message("Line item can't be updated", 422)
    end
  end

  # DELETE /line_items/1
  # DELETE /line_items/1.json
  def destroy
    @line_item.destroy
    @order.amount = @order.amount - @line_item.total
    @order.save
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_line_item
      @line_item = LineItem.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def line_item_params
      params.require(:line_item).permit(:product_name, :quantity, :unit_price, :discount, :total, :order_id, :product_id)
    end
end
