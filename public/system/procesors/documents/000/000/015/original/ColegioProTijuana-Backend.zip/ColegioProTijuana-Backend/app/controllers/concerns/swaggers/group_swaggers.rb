module Swaggers
  module GroupSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/groups' do
        operation :get do
          key :description, 'List of Groups'
          key :operationId, 'Groups'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Group'
          ]
          parameter do
            key :name, :grade_id
            key :in, :query
            key :description, 'ID of Grade to fetch its groups'
            key :required, false
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Groups List fetched successfully'
            schema do
              key :'$ref', :GroupInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Group'
          key :operationId, 'Add Group'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Group'
          ]
          parameter do
            key :name, 'group[grade_id]'
            key :in, :query 
            key :description, 'Grade Id'
            key :required, true
            key :type, :string
            key :'$ref', :GroupInput
          end
          parameter do
            key :name, 'group[name]'
            key :in, :query 
            key :description, 'Group Name'
            key :required, false
            key :type, :string
            key :'$ref', :GroupInput
          end
          parameter do
            key :name, 'group[maximum_capacity]'
            key :in, :query 
            key :description, 'Group capacity'
            key :required, false
            key :type, :integer
            key :'$ref', :GroupInput
          end

          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Group created successfully'
            schema do
              key :'$ref', :GroupInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/groups/{id}' do
        operation :get do
          key :description, 'Returns a group'
          key :operationId, 'find Group By Id'
          key :tags, [
            'Group'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of group to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Group fetched successfully'
            schema do
              key :'$ref', :GroupInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a group '
          key :operationId, 'Update group'
          key :tags, [
            'Group'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of group to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'group[grade_id]'
            key :in, :query 
            key :description, 'Grade Id'
            key :required, false
            key :type, :string
            key :'$ref', :GroupInput
          end
          parameter do
            key :name, 'group[name]'
            key :in, :query 
            key :description, 'Group Name'
            key :required, false
            key :type, :string
            key :'$ref', :GroupInput
          end
          parameter do
            key :name, 'group[maximum_capacity]'
            key :in, :query 
            key :description, 'Group capacity'
            key :required, false
            key :type, :integer
            key :'$ref', :GroupInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Group Updated successfully'
            schema do
              key :'$ref', :GroupInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete group'
          key :operationId, 'delete group'
          key :tags, [
            'Group'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of group to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Group Deleted successfully'
            schema do
              key :'$ref', :GroupInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end
