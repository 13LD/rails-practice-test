class Student < ApplicationRecord

  mount_uploader :student_picture, StudentPictureUploader
  mount_uploader :birth_certificate, BirthCertificateUploader
  mount_uploader :curp_document, CurpDocumentUploader
  mount_uploader :proof_of_address, ProofOfAddressUploader
  mount_uploader :certificate_of_qualifications, CertificateOfQualificationsUploader
  mount_uploader :unsubscribe_folio, UnsubscribeFolioUploader
  mount_uploader :regulation, RegulationUploader

  # Validation
  validate :student_picture_size_validation
  validate :birth_certificate_size_validation
  validate :curp_document_size_validation
  validate :proof_of_address_size_validation
  validate :certificate_of_qualifications_size_validation
  validate :unsubscribe_folio_size_validation
  validate :regulation_size_validation

  validates :first_name, presence: true
  validates :last_name, presence: true
  validates :father_last_name, presence: true
  validates :mother_last_name, presence: true
  validates :email, presence: true
  validates :birthday, presence: true
  validates :sex, presence: true
  validates :address_street, presence: true
  validates :address_colony, presence: true
  validates :address_number, presence: true
  validates :address_postal_code, presence: true
  validates :address_city, presence: true
  validates :age, presence: true
  validates :phone, presence: true
  validates :cell_phone, presence: true
  validates :live_with, presence: true
  validates :type_of_scholarship, presence: true
  validates :curp, presence: true
  validates :rfc, presence: true



  has_many :users_students
  has_many :users, through: :users_students
  has_many :medicines
  has_many :authorized_people
  belongs_to :tutor
  belongs_to :extracurricular_activity
  #load_and_authorize_resource
  has_many :student_group_cycles
  has_many :group_cycles, through: :student_group_cycles  
  has_one :student_current_detail

  def create_enrollment_number
    student_count = Student.where("created_at >= ? ", Date.today.beginning_of_year).count
    student_count = student_count + 1
    self.father_last_name.to_s[0,2].upcase + self.mother_last_name.to_s[0].upcase + self.first_name.to_s[0].upcase + student_count.to_s.rjust(4,"0") + Time.now.year.to_s.last(2)
  end

  def activate_account!
    update_attribute :is_active, true 
  end

  def deactivate_account!
    update_attribute :is_active, false 
  end

  def student_picture_size_validation
    if student_picture? && student_picture.size > 10.megabytes
      errors.add("Student Picture should be less than 10MB")
    end
  end

  def birth_certificate_size_validation
    if birth_certificate? && birth_certificate.size > 10.megabytes
      errors.add("Birth Certificate should be less than 10MB")
    end
  end

  def curp_document_size_validation
    if curp_document? && curp_document.size > 10.megabytes
      errors.add("Curp Document should be less than 10MB")
    end
  end

  def proof_of_address_size_validation
    if proof_of_address? && proof_of_address.size > 10.megabytes
      errors.add("Proof of address should be less than 10MB")
    end
  end

  def certificate_of_qualifications_size_validation
    if certificate_of_qualifications? && certificate_of_qualifications.size > 10.megabytes
      errors.add("Certificate of Qualifications should be less than 10MB")
    end
  end

  def unsubscribe_folio_size_validation
    if unsubscribe_folio? && unsubscribe_folio.size > 10.megabytes
      errors.add("Unsubscribe Folio should be less than 10MB")
    end
  end

  def regulation_size_validation
    if regulation? && regulation.size > 10.megabytes
      errors.add("Regulation should be less than 10MB")
    end
  end
end
