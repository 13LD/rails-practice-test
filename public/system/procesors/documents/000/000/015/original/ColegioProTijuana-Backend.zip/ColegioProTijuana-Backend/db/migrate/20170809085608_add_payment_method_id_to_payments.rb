class AddPaymentMethodIdToPayments < ActiveRecord::Migration[5.0]
  def change
    add_column :payments, :payment_method_id, :integer, index: true
  end
end
