require 'test_helper'

class CycleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
