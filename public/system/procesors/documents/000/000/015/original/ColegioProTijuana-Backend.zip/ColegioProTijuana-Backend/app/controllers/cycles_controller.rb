class CyclesController < ApplicationController
  include Swaggers::CycleSwaggers
  before_action :set_cycle, only: [:show, :update, :destroy]
  before_action :authenticate_user!
 
  # GET /cycles
  def index
    @cycles = Cycle.all
    render_success_response(@cycles)
  end

  # GET /cycles/1
  def show
    if @cycle
      render_success_response(@cycle)
    else
      not_found
    end
  end

  # POST /cycles
  def create
    if params[:cycle]
      @cycle = Cycle.new(cycle_params)
      if @cycle.save
        render_success_response(@cycle)
      else
        render_error_message("Cycle can't be saved", 422)
      end
    else
      render_error_message("Missing Parameters", 422)
    end
  end

  # PATCH/PUT /cycles/1
  def update
    if @cycle 
      @cycle.update(cycle_params)
      render_success_response(@cycle)
    else
      not_found
    end
  end

  # DELETE /cycles/1
  def destroy
    if @cycle
      @cycle.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  def update_cycle_and_student_status
    @cycle = Cycle.find_by(id: params[:id])
    @cycle.update(cycle_params)
    group_cycles = @cycle.group_cycles
    group_cycles.each do |group_cycle|
      student_group_cycles = StudentGroupCycle.where(id: group_cycle.id)
      if params[:cycle][:status] == "inactive" || "inactivo"
        student_group_cycles.update_all(status: 3)
      else
        student_group_cycles.update_all(status: 1)
      end
      render_success_response(@cycle)
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_cycle
      @cycle = Cycle.find_by(id: params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def cycle_params
      params.require(:cycle).permit(:number, :start_date, :end_date, :status)
    end
end
