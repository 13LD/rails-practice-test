class TutorBuilder
  attr_accessor :params

  def initialize(params)
    @params = params
  end

  def execute
    data = @params.dup
    data['tutor'][:students_attributes]= {}
    data['tutor'][:students_attributes]['0'] = data['tutor']['student']
    params = data
  end
end
