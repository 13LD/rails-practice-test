SchoolInformation.create(name: "Test", sep: "test", fiscal_address: "test", rfc: "test", business_name: "test", phone: 1234567890, emergency_phone: 1234567890, legal_guardian: "Test")
SchoolInformation.create(name: "Test1", sep: "test1", fiscal_address: "test1", rfc: "test1", business_name: "test1", phone: 1234567890, emergency_phone: 1234567890, legal_guardian: "Test1")
Role.create(role_type: 0, name: "user", description: "text")
Role.create(role_type: 2, name: "admin", description: "text")