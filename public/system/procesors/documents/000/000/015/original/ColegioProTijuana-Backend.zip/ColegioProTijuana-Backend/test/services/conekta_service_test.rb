require 'test_helper'

class ConektaServiceTest < ActiveSupport::TestCase
  test 'it creates charges' do
    params = {
      amount: 500,
      card: 'TOKEN'
    }
    Conekta::Charge.expects(:create).with(params).returns(true)
    # This will return false if it fails
    charge = ConektaService.new(params).charge
    assert charge
  end

  test 'it creates customers' do
    params = {
      email: 'test@example.card',
      card: 'TOKEN'
    }
    Conekta::Customer.expects(:create).with(params).returns(true)
    # This will return false if it fails
    customer = ConektaService.new(params).create_customer
    assert customer
  end
end