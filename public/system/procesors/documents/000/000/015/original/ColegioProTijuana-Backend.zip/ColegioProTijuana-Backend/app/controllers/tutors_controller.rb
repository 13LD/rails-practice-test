class TutorsController < ApplicationController
  include ActionController::MimeResponds
  include Swaggers::TutorSwaggers
  before_action :set_tutor, only: [:show, :update, :destroy]
  before_action :authenticate_user!
  
  # GET /tutors
  def index
    if params[:user_id]
      @user = User.find_by(id: params[:user_id])
      if @user
        render_success_response(@user.tutor)
      else
        not_found
      end
    else
      @tutors = Tutor.all
      render_success_response(@tutors)
    end
  end

  # GET /tutors/1
  def show
    if @tutor
      render_success_response(@tutor)
    else
      not_found
    end
  end

  # POST /tutors
  def create
    if params[:tutor]
      @tutor = Tutor.new(tutor_params)
      @tutor.user_id = current_user.id
      if @tutor.save
        render_success_response(@tutor)
      else
        render_error_message("Tutor can't be saved", 422)
      end
    else
      render_error_message("Missing Parameters", 422)
    end
  end

  # PATCH/PUT /tutors/1
  def update
    if @tutor 
      @tutor.update(tutor_params)
      render_success_response(@tutor)
    else
      not_found
    end
  end

  # DELETE /tutors/1
  def destroy
    if @tutor
      @tutor.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  def create_tutor_with_student
    if params[:tutor]
      @tutor = Tutor.new(student_with_tutor_params)
      if @tutor.save
        render_success_response(@tutor, include: ['students'])
      else
        render_error_message("Tutor can't be saved", 422)
      end
    else
      render_error_message("Missing Parameters", 422)
    end
  end

  def update_tutor_with_student
    @tutor = Tutor.find_by(id: params[:id])
    if @tutor.update(student_with_tutor_params)
      render_success_response(@tutor, include: {:students => {:include => ['student_current_detail', 'student_group_cycles']}})
    else
      not_found 
    end
  end

  def delete_student
    if current_user
      if params[:id]
        @tutor = Tutor.find_by(user_id: current_user.id)
        @student = Student.find_by(id: params[:id])
        if !@student.nil? && @student.tutor_id == @tutor.id
          @student.destroy
          render_success_response(nil)
        else
          not_found
        end
      end
    end
  end

  def show_students_of_tutor
    @tutor = Tutor.find_by(id: params[:id])
    if @tutor
      render_success_response(@tutor, include: {:students => {:include => ['student_current_detail', 'student_group_cycles']}})
    else
      not_found 
    end
  end

  def show_student_of_tutor
    @tutor = Tutor.find_by(user_id: current_user.id)
    if @tutor
      @student = Student.find_by(id: params[:student_id])

      render_success_response(@tutor, include: {@student => {:include => ['student_current_detail', 'student_group_cycles']}})
    else
      not_found
    end
  end

  def show_tutors_payments
    @tutor = Tutor.find_by(user_id: current_user.id)
    if @tutor
      @user = current_user
      @payments = Payment.all.where(tutor_id: @tutor.id)
        if !@payments.last.nil?
          respond_to do |format|
            format.json { render :json => {:tutor => @tutor, :user => @user , :payment => @payments}}
          end
        else
          respond_to do |format|
            format.json { render :json => {:tutor => @tutor, :user => @user}}
          end
        end
    end
  end

  def last_notification
    @notification = Notification.last
    if @notification
      render_success_response(@notification)
    else
      not_found
    end
  end


  # def payments_report
  #   if current_user
  #     @tutor = Tutor.find_by(user_id: current_user.id)
  #     if @tutor
  #       @payments = Payment.all.where(tutor_id: @tutor.id)
  #       if !@payments.nil?
  #         @payments
  #       else
  #         not_found
  #       end
  #     else
  #       not_found
  #     end
  #   end
  # end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_tutor
      @tutor = Tutor.find_by(id: params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def tutor_params
      params.require(:tutor).permit(:name, :last_name, :father_last_name, :mother_last_name, :title, :phone, :cell_phone, :work_phone, :emergency_phone, :email, :rfc, :curp, :user_id)
    end

    def student_with_tutor_params
      attribute = TutorBuilder.new(params).execute
      attribute['tutor'][:students_attributes]['0'][:created_by] = current_user.id
      attribute.require(:tutor).permit(:name, :last_name, :father_last_name, :mother_last_name, :title, :phone, :cell_phone, :work_phone, :emergency_phone, :email, :rfc, :curp, :user_id, students_attributes: [:id, :email, :first_name, :last_name, :father_last_name, :mother_last_name, :numbers, :created_by, :middle_name, :birthday, :sex, :address_street, :address_colony, :address_number, :address_postal_code, :address_city, :address_state, :control_number, :age, :phone, :cell_phone, :live_with, :type_of_scholarship, :curp, :rfc, :official_docs, :is_active, :tutor_id, :student_picture, :birth_certificate, :curp_document, :proof_of_address, :_destroy])
    end
end
