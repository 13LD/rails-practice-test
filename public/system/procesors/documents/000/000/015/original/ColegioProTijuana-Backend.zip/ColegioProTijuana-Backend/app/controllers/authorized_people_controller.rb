class AuthorizedPeopleController < ApplicationController
  include Swaggers::AuthorizedPersonSwaggers
  before_action :set_authorized_person, only: [:show, :update, :destroy]
  before_action :authenticate_user!

  # GET /authorized_people
  # GET /authorized_people.json
  def index
    @authorized_people = AuthorizedPerson.all
  end

  # GET /authorized_people/1
  # GET /authorized_people/1.json
  def show
  end

  # POST /authorized_people
  # POST /authorized_people.json
  def create
    @authorized_person = AuthorizedPerson.new(authorized_person_params)
    if @authorized_person.save
      render json: @authorized_person
    else
      render json: @authorized_person.errors, status: :unprocessable_entity
    end
  end

  def authorized_people_list
    statuses = []
    if params[:student_id]
      @student = Student.find_by(id: params[:student_id])
      AuthorizedPerson.where(student_id: @student.id).destroy_all
    end
    params[:authorized_people_list].each do |authorized_person_params|
    auth = AuthorizedPerson.new(select_permited(authorized_person_params))
    statuses << ( auth.save ? "OK" : authorized_person.errors )
  end if params[:authorized_people_list]
    render json: statuses
  end

  # PATCH/PUT /authorized_people/1
  # PATCH/PUT /authorized_people/1.json
  def update
    if @authorized_person.update(authorized_person_params)
      render :show, status: :ok, location: @authorized_person
    else
      render json: @authorized_person.errors, status: :unprocessable_entity
    end
  end

  # DELETE /authorized_people/1
  # DELETE /authorized_people/1.json
  def destroy
    @authorized_person.destroy
  end

  private
    def select_permited(authorized_person_params)
      authorized_person_params.permit(:name, :student_id)
    end
    # Use callbacks to share common setup or constraints between actions.
    def set_authorized_person
      @authorized_person = AuthorizedPerson.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def authorized_person_params
      params.require(:authorized_person).permit(:name, :student_id)
    end
end
