class AllotmentsController < ApplicationController
  include Swaggers::AllotmentSwaggers

  def create
    @group_cycle = GroupCycle.where(group_id: params[:student_group_cycle][:group_id], cycle_id: params[:student_group_cycle][:cycle_id]).first_or_create
    if @group_cycle.present?
      @student = Student.find(params[:student_group_cycle][:student_id])
      StudentGroupCycle.where(student_id: @student.id).update_all(status: 'pre_inscription')
      @student_group_cycle = StudentGroupCycle.find_or_create_by(student_id: @student.id ,group_cycle_id: @group_cycle.id)
      @student_group_cycle.update(status: 'inscrito', payment_type: params[:student_group_cycle][:payment_type])
      render json: @student_group_cycle, status: :created
    else
      render json: @student_group_cycle.errors, status: :unprocessable_entity
    end
  end
end
