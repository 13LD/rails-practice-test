/* 
 * conekta.js v1.0.0
 * Conekta 2013
 * https://github.com/conekta/conekta.js/blob/master/LICENSE.txt
 */
