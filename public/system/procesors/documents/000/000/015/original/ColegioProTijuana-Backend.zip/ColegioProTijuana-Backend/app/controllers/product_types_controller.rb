class ProductTypesController < ApplicationController
  include Swaggers::ProductTypeSwaggers
  before_action :set_product_type, only: [:show, :update, :destroy]
  before_action :authenticate_user!

  # GET /product_types
  def index
    if params[:school_information_id]
      @school_information = SchoolInformation.find_by(id: params[:school_information_id])
      if @school_information
        render_success_response(@school_information.product_types)
      else
        not_found
      end
    else
      @product_types = ProductType.all
      render_success_response(@product_types)
    end
  end

  # GET /product_types/1
  def show
    if @product_type
      render_success_response(@product_type)
    else
      not_found
    end
  end

  # POST /product_types
  def create
    if SchoolInformation.exists?(params[:product_type][:school_information_id])
      if params[:product_type]
        @product_type = ProductType.new(product_type_params)
        if @product_type.save
          render_success_response(@product_type)
        else
          render_error_message("Product Type can't be saved", 422)
        end
      else
        render_error_message("Missing Parameters", 422)
      end
    else
      render_error_message("School Information Id doesn't exists", 422)
    end
  end

  # PATCH/PUT /product_types/1
  def update
    if SchoolInformation.exists?(params[:product_type][:school_information_id])
      if @product_type 
        @product_type.update(product_type_params)
        render_success_response(@product_type)
      else
        not_found
      end
    else
      render_error_message("School Information Id doesn't exists", 422)
    end
  end

  # DELETE /product_types/1
  def destroy
    if @product_type
      @product_type.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_product_type
      @product_type = ProductType.find_by(id: params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def product_type_params
      params.require(:product_type).permit(:name, :description, :school_information_id)
    end
end
