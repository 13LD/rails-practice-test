module Swaggers
  module RoleSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :Role do
        key :required, [:id, :role_type, :user_id, :name, :description]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :role_type do
          key :type, :integer
        end
        property :user_id do
          key :type, :integer
        end
        property :name do
          key :type, :string
        end
        property :description do
          key :type, :text
        end
      end

      swagger_schema :RoleInput do
        allOf do
          schema do
            key :'$ref', :Role
          end
          schema do
            key :required, [:role_type, :user_id, :name, :description]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end