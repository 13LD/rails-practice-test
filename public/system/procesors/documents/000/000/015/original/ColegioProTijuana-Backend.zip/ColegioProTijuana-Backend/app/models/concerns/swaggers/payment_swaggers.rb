module Swaggers
  module PaymentSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :Payment do
        key :required, [:id, :student_id, :tutor_id, :status, :amount, :created_by, :product_type_id, :payment_method_id]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :student_id do
          key :type, :integer
        end
        property :tutor_id do
          key :type, :integer
        end
        property :status do
          key :type, :string
        end
        property :amount do
          key :type, :integer
        end
        property :created_by do
          key :type, :integer
        end
        property :product_type_id do
          key :type, :integer
        end
        property :payment_method_id do
          key :type, :integer
        end
        property :order_id do
          key :type, :integer
        end
      end

      swagger_schema :PaymentInput do
        allOf do
          schema do
            key :'$ref', :Payment
          end
          schema do
            key :required, [:student_id, :tutor_id, :status, :amount, :created_by, :product_type_id, :payment_method_id, order_id]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end