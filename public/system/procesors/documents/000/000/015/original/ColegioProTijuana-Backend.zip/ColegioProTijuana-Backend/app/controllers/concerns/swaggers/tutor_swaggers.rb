module Swaggers
  module TutorSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/tutors' do
        operation :get do
          key :description, 'List of Tutors'
          key :operationId, 'Tutors'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Tutor'
          ]
          parameter do
            key :name, :user_id
            key :in, :query
            key :description, 'ID of User to fetch its Tutors'
            key :required, false
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Tutors List fetched successfully'
            schema do
              key :'$ref', :TutorInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end

        operation :post do
          key :description, 'Creates a new Tutor'
          key :operationId, 'Add Tutor'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Tutor'
          ]

          parameter do
            key :name, 'tutor[name]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[last_name]'
            key :in, :query 
            key :description, 'Tutor Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[father_last_name]'
            key :in, :query 
            key :description, 'Tutor Father Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[mother_last_name]'
            key :in, :query 
            key :description, 'Tutor Mother Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[title]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[phone]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[cell_phone]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[work_phone]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[emergency_phone]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[email]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[rfc]'
            key :in, :query 
            key :description, 'RFC'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[curp]'
            key :in, :query 
            key :description, 'CURP'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Tutor created successfully'
            schema do
              key :'$ref', :TutorInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/create_tutor_with_student' do
        operation :post do
          key :description, 'Creates a new Tutor with Student'
          key :operationId, 'Add Tutor with Student'
          key :produces, [
            'application/json'
          ]
          key :consumes, [
            'multipart/form-data'
          ]
          key :tags, [
            'Tutor'
          ]

          parameter do
            key :name, 'tutor[name]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[last_name]'
            key :in, :formData 
            key :description, 'Tutor Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[father_last_name]'
            key :in, :formData 
            key :description, 'Tutor Father Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[mother_last_name]'
            key :in, :formData 
            key :description, 'Tutor Mother Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[title]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[phone]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[cell_phone]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[work_phone]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[emergency_phone]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[email]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[rfc]'
            key :in, :formData 
            key :description, 'RFC'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[curp]'
            key :in, :formData 
            key :description, 'CURP'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][first_name]'
            key :in, :formData
            key :description, 'Student First Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][last_name]'
            key :in, :formData 
            key :description, 'Student Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][father_last_name]'
            key :in, :formData 
            key :description, 'Student Father Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][mother_last_name]'
            key :in, :formData 
            key :description, 'Student Mother Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][numbers]'
            key :in, :formData 
            key :description, 'Numbers'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][email]'
            key :in, :formData 
            key :description, 'Student Email'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][middle_name]'
            key :in, :formData 
            key :description, 'Student Middle Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][birthday]'
            key :in, :formData 
            key :description, 'Student Birthday'
            key :required, false
            key :type, :date
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][sex]'
            key :in, :formData 
            key :description, 'Student sex'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][address_street]'
            key :in, :formData 
            key :description, 'Student Address Street'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][address_colony]'
            key :in, :formData 
            key :description, 'Student Address Colony'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][address_number]'
            key :in, :formData 
            key :description, 'Student Address Number'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][address_postal_code]'
            key :in, :formData 
            key :description, 'Student Address Postal code'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][address_city]'
            key :in, :formData 
            key :description, 'Student Address City'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][address_state]'
            key :in, :formData 
            key :description, 'Student Address State'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][control_number]'
            key :in, :formData 
            key :description, 'Student Control number'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][age]'
            key :in, :formData 
            key :description, 'Student Age'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][phone]'
            key :in, :formData 
            key :description, 'Student Phone No.'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][cell_phone]'
            key :in, :formData 
            key :description, 'Student Cell Phone'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][live_with]'
            key :in, :formData 
            key :description, 'Student First Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][type_of_scholarship]'
            key :in, :formData 
            key :description, 'Type of Scholarship'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][curp]'
            key :in, :formData 
            key :description, 'Student Curp'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][rfc]'
            key :in, :formData 
            key :description, 'Student Rfc'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][official_docs]'
            key :in, :formData 
            key :description, 'Student Official docs'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][student_picture]'
            key :in, :formData 
            key :description, 'Student Picture'
            key :required, false
            key :type, :file
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][birth_certificate]'
            key :in, :formData 
            key :description, 'Birth Certificate of Student'
            key :required, false
            key :type, :file
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][curp_document]'
            key :in, :formData 
            key :description, 'Curp Document of student'
            key :required, false
            key :type, :file
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][proof_of_address]'
            key :in, :formData 
            key :description, 'Address Proof of students'
            key :required, false
            key :type, :file
            key :'$ref', :TutorInput
          end

          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Tutor created successfully'
            schema do
              key :'$ref', :TutorInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/update_tutor_with_student/{id}' do
        operation :put do
          key :description, 'Updates a Tutor with Student'
          key :operationId, 'Update Tutor with Student'
          key :produces, [
            'application/json'
          ]
          key :consumes, [
            'multipart/form-data'
          ]
          key :tags, [
            'Tutor'
          ]

          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Tutor to Update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'tutor[student][id]'
            key :in, :formData 
            key :description, 'Student Id'
            key :required, true
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[name]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[last_name]'
            key :in, :formData 
            key :description, 'Tutor Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[father_last_name]'
            key :in, :formData 
            key :description, 'Tutor Father Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[mother_last_name]'
            key :in, :formData 
            key :description, 'Tutor Mother Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[title]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[phone]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[cell_phone]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[work_phone]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[emergency_phone]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[email]'
            key :in, :formData 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[rfc]'
            key :in, :formData 
            key :description, 'RFC'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[curp]'
            key :in, :formData 
            key :description, 'CURP'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][first_name]'
            key :in, :formData
            key :description, 'Student First Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][last_name]'
            key :in, :formData 
            key :description, 'Student Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
           parameter do
            key :name, 'tutor[student][father_last_name]'
            key :in, :formData 
            key :description, 'Student Father Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][mother_last_name]'
            key :in, :formData 
            key :description, 'Student Mother Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][numbers]'
            key :in, :formData 
            key :description, 'Numbers'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][email]'
            key :in, :formData 
            key :description, 'Student Email'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][middle_name]'
            key :in, :formData 
            key :description, 'Student Middle Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][birthday]'
            key :in, :formData 
            key :description, 'Student Birthday'
            key :required, false
            key :type, :date
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][sex]'
            key :in, :formData 
            key :description, 'Student sex'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][address_street]'
            key :in, :formData 
            key :description, 'Student Address Street'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][address_colony]'
            key :in, :formData 
            key :description, 'Student Address Colony'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][address_number]'
            key :in, :formData 
            key :description, 'Student Address Number'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][address_postal_code]'
            key :in, :formData 
            key :description, 'Student Address Postal code'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][address_city]'
            key :in, :formData 
            key :description, 'Student Address City'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][address_state]'
            key :in, :formData 
            key :description, 'Student Address State'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][control_number]'
            key :in, :formData 
            key :description, 'Student Control number'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][age]'
            key :in, :formData 
            key :description, 'Student Age'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][phone]'
            key :in, :formData 
            key :description, 'Student Phone No.'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][cell_phone]'
            key :in, :formData 
            key :description, 'Student Cell Phone'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][live_with]'
            key :in, :formData 
            key :description, 'Student First Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][type_of_scholarship]'
            key :in, :formData 
            key :description, 'Type of Scholarship'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][curp]'
            key :in, :formData 
            key :description, 'Student Curp'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][rfc]'
            key :in, :formData 
            key :description, 'Student Rfc'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][official_docs]'
            key :in, :formData 
            key :description, 'Student Official docs'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][student_picture]'
            key :in, :formData 
            key :description, 'Student Picture'
            key :required, false
            key :type, :file
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][birth_certificate]'
            key :in, :formData 
            key :description, 'Birth Certificate of Student'
            key :required, false
            key :type, :file
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][curp_document]'
            key :in, :formData 
            key :description, 'Curp Document of student'
            key :required, false
            key :type, :file
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[student][proof_of_address]'
            key :in, :formData 
            key :description, 'Address Proof of students'
            key :required, false
            key :type, :file
            key :'$ref', :TutorInput
          end

          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Tutor Updated successfully'
            schema do
              key :'$ref', :TutorInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/delete_student/{id}' do
        operation :delete do
          key :description, 'Delete a Students of Tutor'
          key :operationId, 'Delete Students By Tutor'
          key :tags, [
              'Tutor'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Tutor to delete its Students'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Students of Tutor delete successfully'
            schema do
              key :'$ref', :TutorInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end

      swagger_path '/show_students_of_tutor/{id}' do
        operation :get do
          key :description, 'Returns a Students of Tutor'
          key :operationId, 'Find Students By Tutor Id'
          key :tags, [
            'Tutor'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Tutor to fetch its Students'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Students of Tutor fetched successfully'
            schema do
              key :'$ref', :TutorInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
      swagger_path '/show_student_enrollment/{id}' do
        operation :get do
          key :description, 'Returns a Student of Tutor'
          key :operationId, 'Find Student By Tutor Id and Student ID'
          key :tags, [
              'Tutor'
          ]

          parameter do
            key :name, :student_id
            key :in, :path
            key :description, 'ID of Student to fetch its Students'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Students of Tutor fetched successfully'
            schema do
              key :'$ref', :TutorInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
      swagger_path '/show_tutors_payments/' do
        operation :get do
          key :description, 'Returns a payment status of Tutor'
          key :operationId, 'Returns a payment status of Tutor'
          key :tags, [
            'Tutor'
          ]
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Payment status of Tutor fetched successfully'
            schema do
              key :'$ref', :TutorInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end

      swagger_path '/last_notification/' do
        operation :get do
          key :description, 'Returns a last notification'
          key :operationId, 'Returns a last notification'
          key :tags, [
              'Tutor'
          ]

          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Last notification'
            schema do
              key :'$ref', :TutorInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end

      swagger_path '/tutors/{id}' do
        operation :get do
          key :description, 'Returns a Tutor'
          key :operationId, 'find Tutor By Id'
          key :tags, [
            'Tutor'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Tutor to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Tutor fetched successfully'
            schema do
              key :'$ref', :TutorInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a Tutor '
          key :operationId, 'Update Tutor'
          key :tags, [
            'Tutor'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Tutor to Update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
           parameter do
            key :name, 'tutor[name]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[last_name]'
            key :in, :query 
            key :description, 'Tutor Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[father_last_name]'
            key :in, :query 
            key :description, 'Tutor Father Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[mother_last_name]'
            key :in, :query 
            key :description, 'Tutor Mother Last Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[title]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[phone]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[cell_phone]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[work_phone]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[emergency_phone]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[email]'
            key :in, :query 
            key :description, 'Tutor Name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[rfc]'
            key :in, :query 
            key :description, 'RFC'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'tutor[curp]'
            key :in, :query 
            key :description, 'CURP'
            key :required, false
            key :type, :string
            key :'$ref', :TutorInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Tutor Updated successfully'
            schema do
              key :'$ref', :TutorInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Tutor'
          key :operationId, 'delete Tutor'
          key :tags, [
            'Tutor'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Tutor to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Tutor Deleted successfully'
            schema do
              key :'$ref', :TutorInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end
