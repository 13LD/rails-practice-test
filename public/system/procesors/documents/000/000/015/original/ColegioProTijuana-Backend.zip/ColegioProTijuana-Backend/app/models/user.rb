class User < ApplicationRecord
  require "twilio-ruby"
  after_create :register_with_customer_conekta
  # Include default devise modules  :confirmable.
  attr_accessor :role_type

  devise  :database_authenticatable, :registerable,
          :recoverable, :rememberable, :trackable, :validatable,
          :omniauthable, :invitable, :invite_for => 2.weeks
        
  include DeviseTokenAuth::Concerns::User

  belongs_to :role
  # after_create :set_role
  before_save :add_role
  after_create :send_confirmation_email, if: -> { !Rails.env.test? && User.devise_modules.include?(:confirmable) }
  validates :name, presence: true
  has_many :users_students
  has_many :students, through: :users_students

  belongs_to :school_information
  has_one :tutor, dependent: :destroy

  has_many :orders

  def has_role?(rolehh)
    role.role_type == rolehh
  end

  def add_role
    @role = Role.where(role_type: 0).last
    if self.role_id.nil?
        self.update(
            :role_id => @role.id
        )
    end
  end

  def role_type
    role = Role.find_by_id(self.role_id)
    role.role_type
  end

  private

    def set_role
      if self.invited_by_id.present?
        create_role(role_type: 3)
        send_invitation_sms
      else
        create_role(role_type: 0)
      end
    end

    def send_invitation_sms
      @client = Twilio::REST::Client.new ENV['account_sid'], ENV['auth_token']
      @client.messages.create(
        # from is the purchased number to send sms
        from: "+18584616738",
        to: "#{self.mobile}",
        body: 'Hey there! You have been invited to pro-tijuana. To activate click here' + "http://localhost:3000/auth/invitation/accept?invitation_token=#{self.invitation_token}"
      )
    end

    def send_confirmation_email
      self.send_confirmation_instructions
    end

    def register_with_customer_conekta
      customer = CustomerConektaService.new(self).create_customer
      update_attributes(customer_id: customer["id"])
    end
end
