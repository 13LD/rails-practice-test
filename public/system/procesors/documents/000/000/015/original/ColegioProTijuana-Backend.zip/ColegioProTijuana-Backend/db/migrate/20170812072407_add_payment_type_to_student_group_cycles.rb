class AddPaymentTypeToStudentGroupCycles < ActiveRecord::Migration[5.0]
  def change
    add_column :student_group_cycles, :payment_type, :integer
  end
end
