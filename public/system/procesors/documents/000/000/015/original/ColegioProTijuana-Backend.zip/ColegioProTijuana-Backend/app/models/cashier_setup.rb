class CashierSetup < ApplicationRecord
  enum period: [:daily, :weekly, :monthly]

  # Validation
  validates :cashier_cut, presence: true
  validates :cashier_cut_frequency, presence: true
  validates :initial_cash, presence: true
  validates :period, presence: true
  validates :max_amount, presence: true

  def to_json
    {:id => id, :initial_cash => initial_cash, :period => period}
  end
end
