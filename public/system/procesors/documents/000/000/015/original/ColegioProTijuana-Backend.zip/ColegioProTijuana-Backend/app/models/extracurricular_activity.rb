class ExtracurricularActivity < ApplicationRecord

  # Validation
  validates :name, presence: true
  validates :description, presence: true
  belongs_to :academic_level
end
