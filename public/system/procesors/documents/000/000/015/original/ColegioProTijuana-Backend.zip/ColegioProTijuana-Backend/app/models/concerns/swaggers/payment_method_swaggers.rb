module Swaggers
  module PaymentMethodSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :PaymentMethod do
        key :required, [:id, :name, :description]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :name do
          key :type, :string
        end
        property :description do
          key :type, :text
        end
      end

      swagger_schema :PaymentMethodInput do
        allOf do
          schema do
            key :'$ref', :PaymentMethod
          end
          schema do
            key :required, [:name, :description]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end