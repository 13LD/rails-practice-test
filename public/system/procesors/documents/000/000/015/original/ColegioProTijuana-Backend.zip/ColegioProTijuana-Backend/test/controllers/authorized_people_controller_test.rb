require 'test_helper'

class AuthorizedPeopleControllerTest < ActionDispatch::IntegrationTest
  setup do
    @authorized_person = authorized_people(:one)
  end

  test "should get index" do
    get authorized_people_url, as: :json
    assert_response :success
  end

  test "should create authorized_person" do
    assert_difference('AuthorizedPerson.count') do
      post authorized_people_url, params: { authorized_person: {  } }, as: :json
    end

    assert_response 201
  end

  test "should show authorized_person" do
    get authorized_person_url(@authorized_person), as: :json
    assert_response :success
  end

  test "should update authorized_person" do
    patch authorized_person_url(@authorized_person), params: { authorized_person: {  } }, as: :json
    assert_response 200
  end

  test "should destroy authorized_person" do
    assert_difference('AuthorizedPerson.count', -1) do
      delete authorized_person_url(@authorized_person), as: :json
    end

    assert_response 204
  end
end
