class RemoveStudentsFields < ActiveRecord::Migration[5.0]
  def change
  	remove_column :students, :authorized_persons
  	remove_column :students, :medicines
  end
end
