module Swaggers
  module SchoolInformationSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/school_informations' do 
        operation :get do
          key :description, 'List of School Informations'
          key :operationId, 'School Informations'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'School information'
          ]
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'School Informations List fetched successfully'
            schema do
              key :'$ref', :SchoolInformationInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end

        operation :post do
          key :description, 'Creates a new School Information'
          key :operationId, 'Add School Information'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'School information'
          ]

          parameter do
            key :name, 'school_information[name]'
            key :in, :query 
            key :description, 'School Information Name'
            key :required, false
            key :type, :string
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[sep]'
            key :in, :query 
            key :description, 'School Information Sep'
            key :required, false
            key :type, :string
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[fiscal_address]'
            key :in, :query 
            key :description, 'School Information Fiscal address'
            key :required, false
            key :type, :string
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[rfc]'
            key :in, :query 
            key :description, 'School Information Rfc'
            key :required, false
            key :type, :string
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[business_name]'
            key :in, :query 
            key :description, 'School Information Business name'
            key :required, false
            key :type, :string
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[phone]'
            key :in, :query 
            key :description, 'School Information Phone'
            key :required, false
            key :type, :integer
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[emergency_phone]'
            key :in, :query 
            key :description, 'School Information Emergency phone'
            key :required, false
            key :type, :integer
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[legal_guardian]'
            key :in, :query 
            key :description, 'School Information Legal guardian'
            key :required, false
            key :type, :string
            key :'$ref', :SchoolInformationInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'School Information created successfully'
            schema do
              key :'$ref', :SchoolInformationInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/school_informations/{id}' do
        operation :get do
          key :description, 'Returns a single School Information'
          key :operationId, 'find School Information By Id'
          key :tags, [
            'School information'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of School information to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'School Information fetched successfully'
            schema do
              key :'$ref', :SchoolInformationInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a School information'
          key :operationId, 'Update School information'
          key :tags, [
            'School information'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of School information to Update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'school_information[name]'
            key :in, :query 
            key :description, 'School Information Name'
            key :required, false
            key :type, :string
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[sep]'
            key :in, :query 
            key :description, 'School Information Sep'
            key :required, false
            key :type, :string
            key :'$ref', :SchoolInformationInput
          end 
          parameter do
            key :name, 'school_information[fiscal_address]'
            key :in, :query 
            key :description, 'School Information Fiscal address'
            key :required, false
            key :type, :string
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[rfc]'
            key :in, :query 
            key :description, 'School Information Rfc'
            key :required, false
            key :type, :string
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[business_name]'
            key :in, :query 
            key :description, 'School Information Business name'
            key :required, false
            key :type, :string
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[phone]'
            key :in, :query 
            key :description, 'School Information Phone'
            key :required, false
            key :type, :integer
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[emergency_phone]'
            key :in, :query 
            key :description, 'School Information Emergency phone'
            key :required, false
            key :type, :integer
            key :'$ref', :SchoolInformationInput
          end
          parameter do
            key :name, 'school_information[legal_guardian]'
            key :in, :query 
            key :description, 'School Information Legal guardian'
            key :required, false
            key :type, :string
            key :'$ref', :SchoolInformationInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'School Information Updated successfully'
            schema do
              key :'$ref', :SchoolInformationInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete School Information'
          key :operationId, 'delete School Information'
          key :tags, [
            'School information'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of School information to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'School Information Deleted successfully'
            schema do
              key :'$ref', :SchoolInformationInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end