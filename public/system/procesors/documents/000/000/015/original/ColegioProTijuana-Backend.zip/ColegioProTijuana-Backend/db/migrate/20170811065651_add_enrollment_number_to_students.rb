class AddEnrollmentNumberToStudents < ActiveRecord::Migration[5.0]
  def change
    add_column :students, :enrollment_number, :string
  end
end
