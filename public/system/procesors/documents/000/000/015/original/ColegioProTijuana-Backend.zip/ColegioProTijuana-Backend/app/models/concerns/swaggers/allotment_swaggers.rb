module Swaggers
  module AllotmentSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :StudentGroupCycle do
        key :required, [:id, :cycle_id, :group_id, :student_id, :payment_type]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :cycle_id do
          key :type, :integer
          key :format, :int64
        end
        property :group_id do
          key :type, :integer
          key :format, :int64
        end
        property :student_id do
          key :type, :integer
          key :format, :int64
        end
        property :payment_type do
          key :type, :integer
          key :format, :int64
        end
      end

      swagger_schema :StudentGroupCycleInput do
        allOf do
          schema do
            key :'$ref', :StudentGroupCycle
          end
          schema do
            key :required, [:id, :cycle_id, :group_id, :student_id, :payment_type]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end
