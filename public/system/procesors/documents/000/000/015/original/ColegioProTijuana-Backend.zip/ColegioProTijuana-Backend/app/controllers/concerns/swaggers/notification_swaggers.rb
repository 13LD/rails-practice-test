module Swaggers
  module NotificationSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/notifications' do
        operation :get do
          key :description, 'Returns a Notifications'
          key :operationId, 'List of Notifications'
          key :tags, [
            'Notification'
          ]
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Notification fetched successfully'
            schema do
              key :'$ref', :NotificationInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Notification'
          key :operationId, 'Add Notification'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Notification'
          ]
          parameter do
            key :name, 'notification[message]'
            key :in, :query 
            key :description, 'Notification message'
            key :required, true
            key :type, :string
            key :'$ref', :NotificationInput
          end
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Notification created successfully'
            schema do
              key :'$ref', :NotificationInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/notifications/{id}' do
        operation :get do
          key :description, 'Returns a Notification'
          key :operationId, 'find notification By Id'
          key :tags, [
            'Notification'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Notification to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Notification fetched successfully'
            schema do
              key :'$ref', :NotificationInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update Notification'
          key :operationId, 'Update Notification'
          key :tags, [
            'Notification'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Notification to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'notification[message]'
            key :in, :query 
            key :description, 'Notification message'
            key :required, false
            key :type, :string
            key :'$ref', :NotificationInput
          end
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Notification Updated successfully'
            schema do
              key :'$ref', :NotificationInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Notification'
          key :operationId, 'delete notification'
          key :tags, [
            'Notification'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Notification to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Notification Deleted successfully'
            schema do
              key :'$ref', :NotificationInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end