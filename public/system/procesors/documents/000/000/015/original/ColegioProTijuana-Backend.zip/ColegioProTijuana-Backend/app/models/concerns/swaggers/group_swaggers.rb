module Swaggers
  module GroupSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :Group do
        key :required, [:id, :name, :maximum_capacity]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :name do
          key :type, :string
        end
        property :maximum_capacity do
          key :type, :integer
        end
      end

      swagger_schema :GroupInput do
        allOf do
          schema do
            key :'$ref', :Group
          end
          schema do
            key :required, [:name]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end