class WebhooksController < ApplicationController
  #skip_before_action :verify_authenticity_token

  def receive   
    data = JSON.parse(request.body.read)
    if data['type'] == 'charge.paid'
      payment_method = data['charges']['data']['object']['payment_method']['type']
      msg = 'Tu pago con #{payment_method} ha sido comprobado'
      ExampleMailer.email(data, msg)
    end
    render status: 200
  end
end
