class CreateTutors < ActiveRecord::Migration[5.0]
  def change
    create_table :tutors do |t|
      t.string :name
      t.string :last_name
      t.string :title
      t.integer :phone
      t.integer :cell_phone
      t.integer :work_phone
      t.integer :emergency_phone
      t.string :email

      t.timestamps
    end
  end
end
