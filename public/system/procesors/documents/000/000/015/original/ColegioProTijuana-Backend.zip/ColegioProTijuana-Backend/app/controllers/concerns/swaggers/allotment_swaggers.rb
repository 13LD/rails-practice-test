module Swaggers
  module AllotmentSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/student_group_cycles' do
        operation :post do
          key :description, 'Assign student in group and cycle'
          key :operationId, 'Assign student in group and cycle'
          key :produces, [
            'application/json'
          ]
          key :consumes, [
            'multipart/form-data'
          ]
          key :tags, [
            'StudentGroupCycle'
          ]

          parameter do
            key :name, 'student_group_cycle[cycle_id]'
            key :in, :formData 
            key :description, 'Cycle Id'
            key :required, false
            key :type, :integer
            key :'$ref', :StudentGroupCycleInput
          end
          parameter do
            key :name, 'student_group_cycle[group_id]'
            key :in, :formData 
            key :description, 'Group Id'
            key :required, false
            key :type, :integer
            key :'$ref', :StudentGroupCycleInput
          end
          parameter do
            key :name, 'student_group_cycle[student_id]'
            key :in, :formData 
            key :description, 'Student Id'
            key :required, false
            key :type, :integer
            key :'$ref', :StudentGroupCycleInput
          end
          parameter do
            key :name, 'student_group_cycle[payment_type]'
            key :in, :formData 
            key :enum, [:complete, :installment_ten ,:installment_twelve]
            key :description, 'Payment Type'
            key :required, false
            key :type, :integer
            key :'$ref', :StudentGroupCycleInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Student Assigned successfully'
            schema do
              key :'$ref', :StudentGroupCycleInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end
    end
  end
end
