class CreateCashierSetups < ActiveRecord::Migration[5.0]
  def change
    create_table :cashier_setups do |t|
      t.integer :cashier_cut
      t.integer :cashier_cut_frequency
      t.integer :initial_cash

      t.timestamps
    end
  end
end
