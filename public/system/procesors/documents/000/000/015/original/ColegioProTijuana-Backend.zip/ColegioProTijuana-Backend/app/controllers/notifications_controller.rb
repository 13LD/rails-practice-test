class NotificationsController < ApplicationController
  include Swaggers::NotificationSwaggers
  before_action :set_notification, only: [:show, :update, :destroy]
  before_action :authenticate_user!
  
  def index
    if params[:id]
      @notifications = Notification.find_by(id: params[:id])
      if @notifications
        render_success_response(@notifications)
      else
        not_found
      end
    else
      @notifications = Notification.all
      render_success_response(@notifications)
    end
  end

  def show
    if @notification
      render_success_response(@notification)
    else
      not_found
    end
  end

  def create
    if params[:notification]
      @notification = Notification.new(notification_params)
      if @notification.save
        render_success_response(@notification)
      else
        render_error_message("Notification can't be saved", 422)
      end
    else
      render_error_message("Missing Parameters", 422)
    end
  end


  def update
    if @notification 
      @notification.update(notification_params)
      render_success_response(@notification)
    else
      not_found
    end
  end


  def destroy
    if @notification
      @notification.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    def set_notification
      @notification = Notification.find(params[:id])
    end

    def notification_params
      params.require(:notification).permit(:message)
    end
end
