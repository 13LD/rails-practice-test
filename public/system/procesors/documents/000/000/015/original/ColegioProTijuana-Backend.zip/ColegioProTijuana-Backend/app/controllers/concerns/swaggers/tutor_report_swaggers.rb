module Swaggers
  module TutorReportSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/tutor_reports' do
        operation :get do
          key :description, 'List of Tutor reports'
          key :operationId, 'Tutor reports'
          key :produces, [
              'application/json'
          ]
          key :tags, [
              'Tutor Report'
          ]

          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Tutor reports list fetched successfully'
            schema do
              key :'$ref', :TutorReportInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new tutor report'
          key :operationId, 'Add Tutor Report'
          key :produces, [
              'application/json'
          ]
          key :tags, [
              'Tutor Report'
          ]
          parameter do
            key :name, 'tutor_report[order_id]'
            key :in, :query
            key :description, 'Payment Status'
            key :required, false
            key :type, :string
            key :'$ref', :TutorReportInput
          end
          parameter do
            key :name, 'tutor_report[tutor_id]'
            key :in, :query
            key :description, 'Tutor Id'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorReportInput
          end


          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Tutor Report created successfully'
            schema do
              key :'$ref', :TutorReportInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/tutor_reports/{id}' do
        operation :get do
          key :description, 'Returns a Tutor Report'
          key :operationId, 'find Tutor Report By Id'
          key :tags, [
              'Tutor Report'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Tutor Report to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Payment fetched successfully'
            schema do
              key :'$ref', :TutorReportInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a Tutor Report'
          key :operationId, 'Update Tutor Report'
          key :tags, [
              'Tutor Report'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Tutor Report to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'tutor_report[tutor_name]'
            key :in, :query
            key :description, 'Tutor name'
            key :required, false
            key :type, :string
            key :'$ref', :TutorReportInput
          end
          parameter do
            key :name, 'tutor_report[tutor_curp]'
            key :in, :query
            key :description, 'Tutor curp'
            key :required, false
            key :type, :string
            key :'$ref', :TutorReportInput
          end
          parameter do
            key :name, 'tutor_report[tutor_email]'
            key :in, :query
            key :description, 'Tutor email'
            key :required, false
            key :type, :string
            key :'$ref', :TutorReportInput
          end
          parameter do
            key :name, 'tutor_report[tutor_id]'
            key :in, :query
            key :description, 'Tutor Id'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorReportInput
          end
          parameter do
            key :name, 'tutor_report[user_id]'
            key :in, :query
            key :description, 'User Id'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorReportInput
          end
          parameter do
            key :name, 'tutor_report[order_id]'
            key :in, :query
            key :description, 'Order Id'
            key :required, false
            key :type, :integer
            key :'$ref', :TutorReportInput
          end
          parameter do
            key :name, 'tutor_report[payment_type]'
            key :in, :query
            key :description, 'Payment type'
            key :required, false
            key :type, :string
            key :'$ref', :TutorReportInput
          end
          parameter do
            key :name, 'tutor_report[amount_paid]'
            key :in, :query
            key :description, 'Amount paid'
            key :required, false
            key :type, :float
            key :'$ref', :TutorReportInput
          end
          parameter do
            key :name, 'tutor_report[funded]'
            key :in, :query
            key :description, 'Funded'
            key :required, false
            key :type, :float
            key :'$ref', :TutorReportInput
          end
          parameter do
            key :name, 'tutor_report[pending_amount]'
            key :in, :query
            key :description, 'Pending amount'
            key :required, false
            key :type, :float
            key :'$ref', :TutorReportInput
          end
          parameter do
            key :name, 'tutor_report[total_amount]'
            key :in, :query
            key :description, 'Total amount'
            key :required, false
            key :type, :float
            key :'$ref', :TutorReportInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Tutor Report Updated successfully'
            schema do
              key :'$ref', :TutorReportInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Tutor Report'
          key :operationId, 'delete Tutor Report'
          key :tags, [
              'Tutor Report'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Tutor Report'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Tutor Report Deleted successfully'
            schema do
              key :'$ref', :TutorReportInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end
