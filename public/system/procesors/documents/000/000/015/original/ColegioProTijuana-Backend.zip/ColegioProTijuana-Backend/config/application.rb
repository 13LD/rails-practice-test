require_relative 'boot'

require 'rails/all'

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

module StarterBackend
  class Application < Rails::Application
    config.action_mailer.default_url_options = { :host => 'localhost' }
    config.assets.initialize_on_precompile = false
    config.middleware.use ActionDispatch::Flash
    config.middleware.use Rack::MethodOverride
    config.middleware.use ActionDispatch::Cookies

    # Settings in config/environments/* take precedence over those specified here.
    # Application configuration should go into files in config/initializers
    # -- all .rb files in that directory are automatically loaded.
    # config.middleware.use Rack::Cors do
    #   allow do
    #     origins '*'
    #     resource '*',
    #       :headers => :any,
    #       :expose  => ['access-token', 'expiry', 'token-type', 'uid', 'client'],
    #       :methods => [:get, :post, :options, :delete, :put, :patch, :head]
    #   end
    # end


    config.middleware.use Rack::Cors do
      allow do
        origins '*'
        resource '*',
          :headers => :any,
          :expose  => ['access-token', 'expiry', 'token-type', 'uid', 'client'],
          :methods => [:get, :post, :options, :delete, :put]
      end
    end

    # config.action_dispatch.default_headers.merge!({
    # 'Access-Control-Allow-Origin' => '*',
    # 'Access-Control-Allow-Methods' => 'POST, PUT, PATCH, DELETE, GET, OPTIONS',
    # 'Access-Control-Request-Method' => '*',
    # 'Access-Control-Allow-Headers' => 'Origin, X-Requested-With, Content-Type, Accept, Authorization'
    # })

    config.api_only = true
    config.autoload_paths += %W(#{Rails.root}/app/services)
  end
end
