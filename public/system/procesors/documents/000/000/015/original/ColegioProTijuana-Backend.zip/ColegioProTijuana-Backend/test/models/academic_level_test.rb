require 'test_helper'

class AcademicLevelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
