class CreateSchoolInformations < ActiveRecord::Migration[5.0]
  def change
    create_table :school_informations do |t|
      t.string :name
      t.string :sep
      t.string :fiscal_address
      t.string :rfc
      t.string :business_name
      t.integer :phone
      t.integer :emergency_phone
      t.string :legal_guardian

      t.timestamps
    end
  end
end
