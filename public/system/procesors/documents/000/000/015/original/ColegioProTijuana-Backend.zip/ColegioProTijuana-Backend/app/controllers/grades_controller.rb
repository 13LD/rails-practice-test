class GradesController < ApplicationController
  include Swaggers::GradeSwaggers
  before_action :set_grade, only: [:show, :update, :destroy]
  before_action :authenticate_user!

  # GET /grades
  def index
    if params[:academic_level_id]
      @academic_level = AcademicLevel.find_by(id: params[:academic_level_id])
      if @academic_level
        @grades = Grade.all.where("academic_level_id = ?", @academic_level.id)

        render_success_response(@grades, :include => {:academic_level => {:only => :name}})
      else
        not_found
      end
    else
      @grades = Grade.all
      render_success_response(@grades, :include => {:academic_level => {:only => :name}})
    end
  end

  # GET /grades/1
  def show
    if @grade
      render_success_response(@grade, :include => {:academic_level => {:only => :name}})
    else
      not_found
    end
  end

  # POST /grades
  def create
    if AcademicLevel.exists?(params[:grade][:academic_level_id])
      if params[:grade]
        @grade = Grade.new(grade_params)
        if @grade.save
          render_success_response(@grade, :include => {:academic_level => {:only => :name}})
        else
          render_error_message("Grade can't be saved", 422)
        end
      else
        render_error_message("Missing Parameters", 422)
      end
    else
      render_error_message("Academic Level Id doesn't exists", 422)
    end
  end

  # PATCH/PUT /grades/1
  def update
    if AcademicLevel.exists?(params[:grade][:academic_level_id])
      if @grade 
        @grade.update(grade_params)
        render_success_response(@grade, :include => {:academic_level => {:only => :name}})
      else
        not_found
      end
    else
      render_error_message("Academic Level Id doesn't exists", 422)
    end
  end

  # DELETE /grades/1
  def destroy
    if @grade
      @grade.destroy
      render_success_response(nil)
    else
      not_found
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_grade
      @grade = Grade.find_by(id: params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def grade_params
      params.require(:grade).permit(:name, :academic_level_id)
    end
end
