module Swaggers
  module StudentSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/students' do
        operation :get do
          key :description, 'List of Students'
          key :operationId, 'Students'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Student'
          ]
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Students List fetched successfully'
            schema do
              key :'$ref', :StudentInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end

        operation :post do
          key :description, 'Creates a new Student'
          key :operationId, 'Add Student'
          key :produces, [
            'application/json'
          ]
          key :consumes, [
            'multipart/form-data'
          ]
          key :tags, [
            'Student'
          ]

          parameter do
            key :name, 'student[tutor_id]'
            key :in, :formData 
            key :description, 'Tutor Id'
            key :required, true
            key :type, :integer
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[first_name]'
            key :in, :formData 
            key :description, 'Student First Name'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[last_name]'
            key :in, :formData 
            key :description, 'Student Last Name'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[father_last_name]'
            key :in, :formData 
            key :description, 'Student Father Last Name'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[mother_last_name]'
            key :in, :formData 
            key :description, 'Student Mother Last Name'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[numbers]'
            key :in, :formData 
            key :description, 'Numbers'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[email]'
            key :in, :formData 
            key :description, 'Student Email'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[middle_name]'
            key :in, :formData 
            key :description, 'Student Middle Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[birthday]'
            key :in, :formData 
            key :description, 'Student Birthday'
            key :required, true
            key :type, :date
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[sex]'
            key :in, :formData 
            key :description, 'Student sex'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[address_street]'
            key :in, :formData 
            key :description, 'Student Address Street'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[address_colony]'
            key :in, :formData 
            key :description, 'Student Address Colony'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[address_number]'
            key :in, :formData 
            key :description, 'Student Address Number'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[address_postal_code]'
            key :in, :formData 
            key :description, 'Student Address Postal Code'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[address_city]'
            key :in, :formData 
            key :description, 'Student Address City'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[address_state]'
            key :in, :formData 
            key :description, 'Student Address State'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[control_number]'
            key :in, :formData 
            key :description, 'Student Control number'
            key :required, false
            key :type, :integer
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[age]'
            key :in, :formData 
            key :description, 'Student Age'
            key :required, true
            key :type, :integer
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[phone]'
            key :in, :formData 
            key :description, 'Student Phone No.'
            key :required, true
            key :type, :integer
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[cell_phone]'
            key :in, :formData 
            key :description, 'Student Cell Phone'
            key :required, true
            key :type, :integer
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[live_with]'
            key :in, :formData 
            key :description, 'Student First Name'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[type_of_scholarship]'
            key :in, :formData 
            key :description, 'Type of Scholarship'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[curp]'
            key :in, :formData 
            key :description, 'Student Curp'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[rfc]'
            key :in, :formData 
            key :description, 'Student Rfc'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[official_docs]'
            key :in, :formData 
            key :description, 'Student Official docs'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[student_picture]'
            key :in, :formData 
            key :description, 'Student Picture'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[birth_certificate]'
            key :in, :formData 
            key :description, 'Birth Certificate of Student'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[curp_document]'
            key :in, :formData 
            key :description, 'Curp Document of student'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[proof_of_address]'
            key :in, :formData 
            key :description, 'Address Proof of students'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[certificate_of_qualifications]'
            key :in, :formData 
            key :description, 'Certificate of Qualifications students'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[unsubscribe_folio]'
            key :in, :formData 
            key :description, 'Unsubscribe Folio students'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[regulation]'
            key :in, :formData 
            key :description, 'Regulation of students'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[extended_time]'
            key :in, :formData 
            key :description, 'Extended time'
            key :required, true
            key :type, :boolean
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[extracurricular_activity_id]'
            key :in, :formData 
            key :description, 'Extracurricular activity Id'
            key :required, false
            key :type, :integer
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[extra_contact_number]'
            key :in, :formData 
            key :description, 'Extra Contact Number'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[extra_contact_email]'
            key :in, :formData 
            key :description, 'Extra Contact Email'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[father_name]'
            key :in, :formData 
            key :description, 'Father Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[mother_name]'
            key :in, :formData 
            key :description, 'Mother Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[has_disease]'
            key :in, :formData 
            key :description, 'Has disease'
            key :required, true
            key :type, :boolean
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[disease_name]'
            key :in, :formData 
            key :description, 'Disease Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[has_allergic]'
            key :in, :formData 
            key :description, 'Has Allergic'
            key :required, true
            key :type, :boolean
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[allergic_name]'
            key :in, :formData 
            key :description, 'Allergic Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[has_treatment]'
            key :in, :formData 
            key :description, 'Has Treatment'
            key :required, true
            key :type, :boolean
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[treatment_name]'
            key :in, :formData 
            key :description, 'Treatment Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[doctor_name]'
            key :in, :formData 
            key :description, 'Doctor Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[doctor_number]'
            key :in, :formData 
            key :description, 'Doctor Number'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[has_to_take_medicine]'
            key :in, :formData 
            key :description, 'Has To Take Medicine'
            key :required, true
            key :type, :boolean
            key :'$ref', :StudentInput
          end
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Student created successfully'
            schema do
              key :'$ref', :StudentInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/students/{id}' do
        operation :get do
          key :description, 'Returns a Student'
          key :operationId, 'find Student By Id'
          key :tags, [
            'Student'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Student to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Student fetched successfully'
            schema do
              key :'$ref', :StudentInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a Student '
          key :operationId, 'Update Student'
          key :tags, [
            'Student'
          ]
          key :consumes, [
            'multipart/form-data'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Student to Update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'student[tutor_id]'
            key :in, :formData
            key :description, 'Tutor Id'
            key :required, true
            key :type, :integer
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[first_name]'
            key :in, :formData
            key :description, 'Student First Name'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[last_name]'
            key :in, :formData
            key :description, 'Student Last Name'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[father_last_name]'
            key :in, :formData
            key :description, 'Student Father Last Name'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[mother_last_name]'
            key :in, :formData
            key :description, 'Student Mother Last Name'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[numbers]'
            key :in, :formData
            key :description, 'Numbers'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[email]'
            key :in, :formData
            key :description, 'Student Email'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[middle_name]'
            key :in, :formData
            key :description, 'Student Middle Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[birthday]'
            key :in, :formData
            key :description, 'Student Birthday'
            key :required, true
            key :type, :date
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[sex]'
            key :in, :formData
            key :description, 'Student sex'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[address_street]'
            key :in, :formData
            key :description, 'Student Address Street'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[address_colony]'
            key :in, :formData
            key :description, 'Student Address Colony'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[address_number]'
            key :in, :formData
            key :description, 'Student Address Number'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[address_postal_code]'
            key :in, :formData
            key :description, 'Student Address Postal Code'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[address_city]'
            key :in, :formData
            key :description, 'Student Address City'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[address_state]'
            key :in, :formData
            key :description, 'Student Address State'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[control_number]'
            key :in, :formData
            key :description, 'Student Control number'
            key :required, false
            key :type, :integer
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[age]'
            key :in, :formData
            key :description, 'Student Age'
            key :required, true
            key :type, :integer
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[phone]'
            key :in, :formData
            key :description, 'Student Phone No.'
            key :required, true
            key :type, :integer
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[cell_phone]'
            key :in, :formData
            key :description, 'Student Cell Phone'
            key :required, true
            key :type, :integer
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[live_with]'
            key :in, :formData
            key :description, 'Student First Name'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[type_of_scholarship]'
            key :in, :formData
            key :description, 'Type of Scholarship'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[curp]'
            key :in, :formData
            key :description, 'Student Curp'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[rfc]'
            key :in, :formData
            key :description, 'Student Rfc'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[official_docs]'
            key :in, :formData
            key :description, 'Student Official docs'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[student_picture]'
            key :in, :formData
            key :description, 'Student Picture'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[birth_certificate]'
            key :in, :formData
            key :description, 'Birth Certificate of Student'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[curp_document]'
            key :in, :formData
            key :description, 'Curp Document of student'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[proof_of_address]'
            key :in, :formData
            key :description, 'Address Proof of students'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[certificate_of_qualifications]'
            key :in, :formData
            key :description, 'Certificate of Qualifications students'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[unsubscribe_folio]'
            key :in, :formData
            key :description, 'Unsubscribe Folio students'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[regulation]'
            key :in, :formData
            key :description, 'Regulation of students'
            key :required, false
            key :type, :file
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[extended_time]'
            key :in, :formData
            key :description, 'Extended time'
            key :required, true
            key :type, :boolean
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[extracurricular_activity_id]'
            key :in, :formData
            key :description, 'Extracurricular activity Id'
            key :required, false
            key :type, :integer
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[extra_contact_number]'
            key :in, :formData
            key :description, 'Extra Contact Number'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[extra_contact_email]'
            key :in, :formData
            key :description, 'Extra Contact Email'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[father_name]'
            key :in, :formData
            key :description, 'Father Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[mother_name]'
            key :in, :formData
            key :description, 'Mother Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[has_disease]'
            key :in, :formData
            key :description, 'Has disease'
            key :required, true
            key :type, :boolean
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[disease_name]'
            key :in, :formData
            key :description, 'Disease Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[has_allergic]'
            key :in, :formData
            key :description, 'Has Allergic'
            key :required, true
            key :type, :boolean
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[allergic_name]'
            key :in, :formData
            key :description, 'Allergic Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[has_treatment]'
            key :in, :formData
            key :description, 'Has Treatment'
            key :required, true
            key :type, :boolean
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[treatment_name]'
            key :in, :formData
            key :description, 'Treatment Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[doctor_name]'
            key :in, :formData
            key :description, 'Doctor Name'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[doctor_number]'
            key :in, :formData
            key :description, 'Doctor Number'
            key :required, false
            key :type, :string
            key :'$ref', :StudentInput
          end
          parameter do
            key :name, 'student[has_to_take_medicine]'
            key :in, :formData
            key :description, 'Has To Take Medicine'
            key :required, true
            key :type, :boolean
            key :'$ref', :StudentInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Student Updated successfully'
            schema do
              key :'$ref', :StudentInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Student'
          key :operationId, 'delete Student'
          key :tags, [
            'Student'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Student to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Student Deleted successfully'
            schema do
              key :'$ref', :StudentInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end

      swagger_path '/students/download_pdf' do 
        operation :get do
          key :description, 'Download student picture'
          key :operationId, 'Download student picture'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Student'
          ]
          parameter do
            key :name, :id
            key :in, :query
            key :description, 'ID of Student to fetch its Document'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, :document
            key :in, :query 
            key :description, 'Document to be downloaded'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          
          response 200 do
            key :description, 'Student Document successfully Downloaded.'
            key :'$ref', :StudentInput
          end
        end
      end

    swagger_path '/students/delete_pdf' do 
        operation :get do
          key :description, 'Delete student picture'
          key :operationId, 'Delete student picture'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Student'
          ]
          parameter do
            key :name, :id
            key :in, :query
            key :description, 'ID of Student to fetch its Document'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, :document
            key :in, :query 
            key :description, 'Document to be deleted'
            key :required, true
            key :type, :string
            key :'$ref', :StudentInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          
          response 200 do
            key :description, 'Student Document successfully Downloaded.'
            key :'$ref', :StudentInput
          end
        end
      end  
    end
  end
end
