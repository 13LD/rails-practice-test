class AddMaximumCapacityToGroups < ActiveRecord::Migration[5.0]
  def change
    add_column :groups, :maximum_capacity, :integer
  end
end
