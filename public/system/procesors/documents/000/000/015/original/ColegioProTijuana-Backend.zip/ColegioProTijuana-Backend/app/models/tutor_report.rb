class TutorReport < ApplicationRecord

  validates :tutor_name, presence: true
  validates :tutor_curp, presence: true
  validates :tutor_email, presence: true
  validates :amount_paid, presence: true
  validates :total_amount, presence: true


  belongs_to :tutor
  belongs_to :user
  belongs_to :order
end
