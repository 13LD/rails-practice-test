require "conekta"
Conekta.api_key = "key_bgoDPpv2sJDZM8qxggbahA"
Conekta.api_version = "2.0.0"
Conekta.locale = :es

