class AddAcademicLevelIdToGrades < ActiveRecord::Migration[5.0]
  def change
    add_column :grades, :academic_level_id, :integer
    add_index :grades, :academic_level_id
  end
end
