class Product < ApplicationRecord
  # Validation
  validates :name, presence: true
  validates :description, presence: true
  validates :price, presence: true
  validates :taxable, presence: true

  belongs_to :product_type

end
