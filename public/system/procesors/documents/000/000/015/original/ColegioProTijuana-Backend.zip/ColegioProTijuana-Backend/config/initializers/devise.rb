Devise.setup do |config|
  # The e-mail address that mail will appear to be sent from
  # If absent, mail is sent from "please-change-me-at-config-initializers-devise@example.com"
  config.mailer_sender = "mailboxtrack@gmail.com"

  # If using rails-api, you may want to tell devise to not use ActionDispatch::Flash
  # middleware b/c rails-api does not include it.
  # See: http://stackoverflow.com/q/19600905/806956
  config.navigational_formats = [:json]
  config.secret_key = 'e7d5e7822c902276b1b9ecace09cc313e3f5048007e00445f050e0d6d37224aa7cd97ad04c532057d8b1292cccdba9ce0117c42b687f6aa1d3606d3e1bbb30b1'
end