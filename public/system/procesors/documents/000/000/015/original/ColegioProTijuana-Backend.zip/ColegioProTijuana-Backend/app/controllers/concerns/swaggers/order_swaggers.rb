module Swaggers
  module OrderSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_path '/orders' do
        operation :get do
          key :description, 'List of Orders'
          key :operationId, 'Orders'
          key :produces, [
           'application/json'
          ]
          key :tags, [
           'Order'
          ]
          
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Orders List fetched successfully'
            schema do
              key :'$ref', :OrderInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :post do
          key :description, 'Creates a new Order'
          key :operationId, 'Add Order'
          key :produces, [
            'application/json'
          ]
          key :tags, [
            'Order'
          ]
        
          parameter do
            key :name, 'order[name]'
            key :in, :query 
            key :description, 'Order Name'
            key :required, false
            key :type, :string
            key :'$ref', :OrderInput
          end
          parameter do
            key :name, 'order[amount]'
            key :in, :query 
            key :description, 'Order Amount'
            key :required, false
            key :type, :integer
            key :'$ref', :OrderInput
          end
          parameter do
            key :name, 'order[quantity]'
            key :in, :query 
            key :description, 'Order Quantity'
            key :required, false
            key :type, :integer
            key :'$ref', :OrderInput
          end
          
          parameter do
            key :name, 'order[payment_type]'
            key :in, :formData 
            key :enum, [:cash, :credit_card, :check, :electronic_transfer]
            key :description, 'Payment Type'
            key :required, false
            key :type, :integer
            key :'$ref', :OrderInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Order created successfully'
            schema do
              key :'$ref', :OrderInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
      end

      swagger_path '/orders/{id}' do
        operation :get do
          key :description, 'Returns a order'
          key :operationId, 'find Order By Id'
          key :tags, [
            'Order'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Order to fetch'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Order fetched successfully'
            schema do
              key :'$ref', :OrderInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
        operation :put do
          key :description, 'Update a Order '
          key :operationId, 'Update Order'
          key :tags, [
            'Order'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Order to update'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          parameter do
            key :name, 'order[payment_method][id]'
            key :in, :formData 
            key :description, 'Payment Method Id'
            key :required, true
            key :type, :string
            key :'$ref', :TutorInput
          end
          parameter do
            key :name, 'order[name]'
            key :in, :query 
            key :description, 'Order Name'
            key :required, false
            key :type, :string
            key :'$ref', :OrderInput
          end
          parameter do
            key :name, 'order[amount]'
            key :in, :query 
            key :description, 'Order Amount'
            key :required, false
            key :type, :integer
            key :'$ref', :OrderInput
          end
          parameter do
            key :name, 'order[quantity]'
            key :in, :query 
            key :description, 'Order Quantity'
            key :required, false
            key :type, :integer
            key :'$ref', :OrderInput
          end
          parameter do
            key :name, 'order[payment_type]'
            key :in, :query 
            key :description, 'Order Payment_type'
            key :required, false
            key :type, :integer
            key :'$ref', :OrderInput
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Order Updated successfully'
            schema do
              key :'$ref', :OrderInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
          response 422 do
            key :description, 'Missing Parameters or Request rejected'
            schema do
              key :'$ref', :RejectRequest
            end
          end
        end
        operation :delete do
          key :description, 'Delete Order'
          key :operationId, 'delete Order'
          key :tags, [
            'Order'
          ]
          parameter do
            key :name, :id
            key :in, :path
            key :description, 'ID of Order to delete'
            key :required, true
            key :type, :integer
            key :format, :int64
          end
          security do
            key 'access-token', []
            key :client, []
            key :uid, []
          end
          response 200 do
            key :description, 'Order Deleted successfully'
            schema do
              key :'$ref', :OrderInput
            end
          end
          response 403 do
            key :description, 'Permission denied'
            schema do
              key :'$ref', :ErrorModel
            end
          end
        end
      end
    end
  end
end
