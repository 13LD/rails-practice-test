module Swaggers
  module ProductSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :Product do
        key :required, [:id, :name, :description, :price, :taxable, :product_typ]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :name do
          key :type, :string
        end
        property :description do
          key :type, :text
        end
        property :price do
          key :type, :integer
        end
        property :taxable do
          key :type, :boolean
        end
        property :product_typ do
          key :type, :string
        end
      end
      
      swagger_schema :ProductInput do
        allOf do
          schema do
            key :'$ref', :Product
          end
          schema do
            key :required, [:name, :description, :price, :taxable, :product_typ]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end