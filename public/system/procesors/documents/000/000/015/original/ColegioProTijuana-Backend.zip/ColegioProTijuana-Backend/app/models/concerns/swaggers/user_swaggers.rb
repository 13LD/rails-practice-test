module Swaggers
  module UserSwaggers
    extend ActiveSupport::Concern
    include Swagger::Blocks
    included do
      swagger_schema :User do
        key :required, [:id, :email, :password, :password_confirmation, :name, :nickname, :position, :user, :area, :active]
        property :id do
          key :type, :integer
          key :format, :int64
        end
        property :email do
          key :type, :string
        end
        property :password do
          key :type, :string
        end
        property :password_confirmation do
          key :type, :string
        end
        property :name do
          key :type, :string
        end
        property :nickname do
          key :type, :string
        end
        property :position do
          key :type, :string
        end
        property :user do
          key :type, :string
        end
        property :area do
          key :type, :string
        end
        property :active do
          key :type, :string
        end
      end

      swagger_schema :UserInput do
        allOf do
          schema do
            key :'$ref', :User
          end
          schema do
            key :required, [:name, :nickname, :email, :password, :password_confirmation, :position, :user, :area, :active]
            property :id do
              key :type, :integer
              key :format, :int64
            end
          end
        end
      end
    end
  end
end
