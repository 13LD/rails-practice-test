class Document < ApplicationRecord
  belongs_to :user
  mount_uploader :document, XlsFileUploader
  after_commit :read_spreadsheet

  def read_spreadsheet
    sheet = Roo::Spreadsheet.open("#{request.base_url}/#{@document.document_url}", extension: :xlsx)
    return if sheet.blank?
    header = sheet.row(1)
    (2..sheet.last_row).each do |i|
      row = Hash[[header, sheet.row(i)].transpose]
      student = Student.find_by_email(row["email"]) || Student.new
      student.attributes = row.to_hash
      student.save!
    end
  end
end